# Nutri AI

A full-stack personalized diet recommendation platform that uses machine learning to generate meal plans based on individual health profiles, activity levels, and nutritional goals. Built with a microservices architecture and deployed on Azure VM with Docker.

**Live at:** [bcrypt.in](https://bcrypt.in)

---

## Architecture

```
┌────────────┐     ┌──────────────────┐     ┌─────────────────┐
│   React    │────▶│   Spring Boot    │────▶│    FastAPI       │
│  Frontend  │     │   (REST API)     │     │  (AI Service)   │
│  :443/80   │     │    :8080         │     │    :8000         │
└────────────┘     └──────────────────┘     └─────────────────┘
                          │                        │
                          ▼                        ▼
                   ┌────────────┐          ┌──────────────┐
                   │  MongoDB   │          │  ML Pipeline │
                   │   :27017   │          │ (RandomForest)│
                   └────────────┘          └──────────────┘
```

Nginx sits in front as a reverse proxy, handling SSL termination and routing:
- `/` → React SPA
- `/api/` → Spring Boot backend
- `/ai/` → FastAPI ML service
- `/oauth2/`, `/login/` → OAuth2 flows

---

## Tech Stack

| Layer | Technology |
|-------|-----------|
| **Frontend** | React 18, Tailwind CSS, Framer Motion, Axios |
| **Backend** | Spring Boot 3.2, Java 21, Spring Security, Spring Data MongoDB |
| **AI Service** | FastAPI, scikit-learn (RandomForestClassifier), Pandas, NumPy |
| **Database** | MongoDB 7 |
| **Auth** | JWT + OAuth2 (Google, GitHub) |
| **Infra** | Docker Compose, Nginx, Let's Encrypt SSL, Azure VM |

---

## Project Structure

```
.
├── ai_service.py                 # FastAPI app — serves diet predictions
├── diet_plan.py                  # ML model training pipeline
├── generate.py                   # Food categorization utility
├── requirements.txt              # Python dependencies
├── Dockerfile                    # AI service container
│
├── smart-nutrition-backend/      # Spring Boot REST API
│   ├── pom.xml
│   ├── Dockerfile
│   └── src/main/java/com/smartnutrition/
│       ├── controller/           # Auth, Diet, User endpoints
│       ├── service/              # Business logic + AI service client
│       ├── model/                # User, DietLog entities
│       ├── repository/           # MongoDB repositories
│       ├── dto/                  # Request/response objects
│       ├── security/             # JWT + OAuth2 config
│       └── config/               # Spring Security, RestTemplate
│
├── smart-nutrition-frontend/     # React SPA
│   ├── src/
│   │   ├── pages/                # Home, Login, Signup, Dashboard, etc.
│   │   ├── components/           # Navbar, Sidebar, ProtectedRoute
│   │   ├── contexts/             # AuthContext, ToastContext
│   │   ├── services/             # API client, diet service
│   │   └── utils/                # Nutrition calculations
│   └── package.json
│
├── deploy/                       # Deployment scripts
│   └── deploy.sh
├── docker-compose.yml            # Production compose
├── docker-compose.local.yml      # Local development compose
├── nginx.conf                    # Reverse proxy config
└── .github/workflows/            # CI/CD pipeline
```

---

## How It Works

1. User signs up (email/password or OAuth2 via Google/GitHub)
2. Fills in a health profile — weight, height, age, activity level, goal, optional vitals
3. Spring Boot sends the profile to FastAPI's `/predict` endpoint
4. The AI service:
   - Computes BMI, BMR, and TDEE based on the profile
   - Calculates target macros (protein, carbs, fat) for the user's goal
   - Generates meal combinations from the Indian food database
   - Scores each combination using the trained RandomForest model
   - Returns the top-scoring lunch and dinner plans with full nutrition breakdown
5. Dashboard displays the personalized diet plan with recommendations

### ML Pipeline

The model is trained on synthetic meal-user pairings:
- **Features:** age, gender, BMI, activity level, blood pressure, blood sugar, sleep hours, smoking status, meal type, calorie/macro totals
- **Label:** meal suitability (binary — does this meal match the user's health profile?)
- **Algorithm:** RandomForestClassifier (100 estimators) wrapped in a sklearn Pipeline with column preprocessing
- **Training data:** Indian food nutrition database + synthetic user profiles

---

## Getting Started

### Prerequisites

- Docker & Docker Compose
- Node.js 18+ (for frontend development)
- Java 21 + Maven (for backend development)
- Python 3.11+ (for AI service development)

### Setup

```bash
# clone the repo
git clone https://github.com/ameyaatmaa/Nutri_Ai.git
cd Nutri_Ai

# copy env template and fill in your values
cp .env.example .env
# edit .env with your MongoDB creds, OAuth keys, JWT secret, etc.
```

### Running with Docker (recommended)

```bash
# build and start everything
docker compose up -d --build

# check status
docker compose ps

# view logs
docker compose logs -f
```

This spins up all four services:
- **MongoDB** on port 27017
- **Spring Boot** on port 8080
- **FastAPI** on port 8000
- **Nginx** on port 80/443

### Running Individually (development)

**AI Service:**
```bash
pip install -r requirements.txt
uvicorn ai_service:app --host 0.0.0.0 --port 8000 --reload
```

**Backend:**
```bash
cd smart-nutrition-backend
./mvnw spring-boot:run
```

**Frontend:**
```bash
cd smart-nutrition-frontend
npm install
npm start
```

### Training the ML Model

If you need to retrain the model (requires the CSV data files in the project root):

```bash
python diet_plan.py
```

This generates `diet_model_pipeline.pkl` which the AI service loads at startup.

---

## API Endpoints

### Spring Boot (`/api/`)
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/auth/signup` | Register new user |
| POST | `/api/auth/login` | Login, returns JWT |
| GET | `/api/users/me` | Get current user profile |
| PUT | `/api/users/me` | Update health profile |
| POST | `/api/diet/predict` | Get personalized diet plan |

### FastAPI (`/ai/`)
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/health` | Service health check |
| POST | `/predict` | ML-based diet prediction |

---

## Deployment

The app is deployed on an Azure VM using Docker Compose with Nginx handling SSL via Let's Encrypt.

```bash
# on the VM
cd /path/to/project
chmod +x deploy/deploy.sh
./deploy/deploy.sh
```

The deploy script handles:
- Stopping old containers
- Rebuilding images
- Starting all services
- Health checks

---

## Environment Variables

See [`.env.example`](.env.example) for all required variables. Key ones:

| Variable | Purpose |
|----------|---------|
| `MONGODB_URI` | MongoDB connection string |
| `GOOGLE_CLIENT_ID/SECRET` | Google OAuth2 credentials |
| `GITHUB_CLIENT_ID/SECRET` | GitHub OAuth2 credentials |
| `JWT_SECRET` | Secret key for signing JWTs |
| `AI_SERVICE_URL` | Internal URL for the FastAPI service |
| `OPENAI_API_KEY` | OpenAI key (optional, for future features) |

---

## Data Files

The following files are needed but excluded from git due to size:

| File | Size | Description |
|------|------|-------------|
| `cleaned_food_data.csv` | ~414 KB | Indian food nutrition database |
| `cleaned_user_data.csv` | ~109 KB | Synthetic user profiles for training |
| `diet_model_pipeline.pkl` | ~21 MB | Pre-trained RandomForest model |

These need to be placed in the project root for the AI service to work. The Dockerfile copies them into the container at build time.
