"""
Smart Nutrition - Python AI Microservice (FastAPI)
====================================================
Replaces the original Flask api.py with a FastAPI wrapper that:
  1. Uses the EXACT same food-selection logic from api.py (predict_diet)
  2. Uses the EXACT same model input schema from generate.py (create_meal_record)
  3. Exposes /predict (called by Spring Boot) instead of /predict_diet

Your existing files used AS-IS:
  - diet_model_pipeline.pkl  -> loaded by joblib, same as before
  - cleaned_food_data.csv    -> same food CSV, same category columns
  - generate.py              -> categorize_food() imported directly

Run:
    pip install -r requirements.txt
    uvicorn ai_service:app --host 0.0.0.0 --port 8000 --reload

Swagger UI: http://localhost:8000/docs
"""

from __future__ import annotations

import logging
import os
import random
from typing import Any, Dict, List, Optional

import joblib
import numpy as np
import pandas as pd
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field, field_validator

# ── Import categorize_food from your existing generate.py ────────
try:
    from generate import categorize_food
    logging.info("categorize_food imported from generate.py")
except ImportError:
    logging.warning("generate.py not found — using inline fallback categorize_food()")

    def categorize_food(food_name: str) -> str:
        name = food_name.lower()
        staple_kw   = ['rice','roti','chapati','bread','naan','paratha','poori','dosa','idli','uttapam','thepla']
        lentil_kw   = ['dal','lentil','moong','masoor','chana','toor','urad','rajma','chickpea','gram']
        curry_kw    = ['curry','sabzi','palak','aloo','gobi','bhindi','karela','baingan','paneer',
                       'chicken','mutton','fish','prawn','avial','sambar','rasam']
        dessert_kw  = ['kheer','halwa','laddu','barfi','rasgulla','gulab jamun','jalebi','kulfi',
                       'ice cream','cake','biscuit','cookie','sweet','mithai','payasam']
        if any(k in name for k in staple_kw):  return 'staple'
        if any(k in name for k in lentil_kw):  return 'lentil'
        if any(k in name for k in dessert_kw): return 'dessert'
        if any(k in name for k in curry_kw):   return 'curry'
        return 'other'


logging.basicConfig(level=logging.INFO, format="%(levelname)s: %(message)s")
logger = logging.getLogger(__name__)

# ── Constants (mirror generate.py / api.py exactly) ───────────────
ACTIVITY_MULTIPLIERS: Dict[str, float] = {
    "sedentary":   1.2,
    "light":       1.375,
    "moderate":    1.55,
    "active":      1.725,
    "very_active": 1.9,
}

GOAL_CALORIE_ADJUSTMENT: Dict[str, int] = {
    "lose":     -500,
    "maintain":    0,
    "gain":     +500,
}

# Meal structure — mirrors api.py predict_diet() meals dict
# Each list is the food category to pull one item from (in order)
MEAL_STRUCTURE: Dict[str, List[str]] = {
    "breakfast": ["staple", "other"],
    "lunch":     ["staple", "lentil", "curry", "dessert"],
    "dinner":    ["staple", "curry", "dessert", "side"],
    "snack":     ["dessert", "other"],
}

# ── Global state ──────────────────────────────────────────────────
model_pipeline = None
food_df: Optional[pd.DataFrame] = None


def _load_resources() -> None:
    global model_pipeline, food_df

    model_path = os.getenv("MODEL_PATH", "diet_model_pipeline.pkl")
    food_path  = os.getenv("FOOD_DATA_PATH", "cleaned_food_data.csv")

    if os.path.exists(model_path):
        try:
            model_pipeline = joblib.load(model_path)
            logger.info(f"Model loaded from {model_path}")
        except Exception as e:
            logger.error(f"Failed to load model: {e}")
    else:
        logger.warning(f"Model file '{model_path}' not found — suitability scoring will use random fallback.")

    if os.path.exists(food_path):
        try:
            food_df = pd.read_csv(food_path).fillna("Unknown")
            if "food_category" not in food_df.columns:
                food_df["food_category"] = food_df["food_name"].apply(categorize_food)
            logger.info(f"Food data loaded: {len(food_df)} rows")
        except Exception as e:
            logger.error(f"Failed to load food data: {e}")
    else:
        logger.warning(f"Food data '{food_path}' not found.")


app = FastAPI(
    title="Smart Nutrition AI Service",
    description="FastAPI wrapper around diet_model_pipeline.pkl. Called by Spring Boot only.",
    version="2.0.0",
)


@app.on_event("startup")
def startup_event():
    _load_resources()


app.add_middleware(
    CORSMiddleware,
    allow_origins=[os.getenv("ALLOWED_ORIGIN", "http://localhost:8080")],
    allow_methods=["GET", "POST"],
    allow_headers=["*"],
)


# ─────────────────────────────────────────────────────────────────
# Pydantic schemas
# ─────────────────────────────────────────────────────────────────

class PredictRequest(BaseModel):
    """
    Spring Boot sends these fields from the User MongoDB document.
    Matches what api.py /predict_diet expected from the React frontend.
    """
    weight_kg:         float = Field(..., gt=20,  lt=300)
    height_cm:         float = Field(..., gt=50,  lt=250)
    age:               int   = Field(..., gt=10,  lt=120)
    gender:            str   = Field(...)
    activity_level:    str   = Field(...)
    goal:              str   = Field(...)

    # Optional vitals — used by the ML model's suitability check (generate.py)
    # Default to healthy baseline values if not provided
    blood_sugar_level: float = Field(default=90.0)
    blood_pressure:    float = Field(default=120.0)
    sleep_hours:       float = Field(default=7.0)
    smokes:            int   = Field(default=0)

    @field_validator("gender")
    @classmethod
    def validate_gender(cls, v: str) -> str:
        if v.lower() not in ("male", "female"):
            raise ValueError("gender must be 'male' or 'female'")
        return v.lower()

    @field_validator("activity_level")
    @classmethod
    def validate_activity(cls, v: str) -> str:
        if v not in ACTIVITY_MULTIPLIERS:
            raise ValueError(f"activity_level must be one of {list(ACTIVITY_MULTIPLIERS.keys())}")
        return v

    @field_validator("goal")
    @classmethod
    def validate_goal(cls, v: str) -> str:
        if v not in GOAL_CALORIE_ADJUSTMENT:
            raise ValueError(f"goal must be one of {list(GOAL_CALORIE_ADJUSTMENT.keys())}")
        return v


class FoodItem(BaseModel):
    food_name:           str
    energy_kcal:         float
    compatibility_score: float


class MealPlan(BaseModel):
    foods:             List[FoodItem]
    total_calories:    float
    avg_compatibility: float


class PredictResponse(BaseModel):
    user_profile:           Dict[str, Any]
    bmi:                    float
    bmi_category:           str
    bmr:                    float
    tdee:                   float
    target_calories:        float
    protein_g:              float
    carbs_g:                float
    fat_g:                  float
    diet_plan:              Dict[str, MealPlan]
    daily_summary:          Dict[str, Any]
    health_recommendations: List[str]


# ─────────────────────────────────────────────────────────────────
# Helpers (ported 1-to-1 from api.py + generate.py)
# ─────────────────────────────────────────────────────────────────

def _calculate_bmi(height_cm: float, weight_kg: float) -> float:
    """Mirrors api.py calculate_bmi()"""
    if height_cm <= 0:
        return 0.0
    return round(weight_kg / ((height_cm / 100) ** 2), 2)


def _get_bmi_category(bmi: float) -> str:
    """Mirrors api.py get_bmi_category()"""
    if bmi < 18.5: return "Underweight"
    if bmi < 25:   return "Normal"
    if bmi < 30:   return "Overweight"
    return "Obese"


def _compute_bmr(weight_kg: float, height_cm: float, age: int, gender: str) -> float:
    """Mifflin-St Jeor"""
    if gender == "male":
        return 10 * weight_kg + 6.25 * height_cm - 5 * age + 5
    return 10 * weight_kg + 6.25 * height_cm - 5 * age - 161


def _score_meal_with_model(user_metrics: dict, foods: List[Any], meal_type: str) -> float:
    """
    Scores a meal combination using the trained RandomForestClassifier.

    Input DataFrame mirrors create_meal_record() column order in generate.py:
    age, gender(M=1/F=0), bmi, activity_index, blood_pressure, blood_sugar_level,
    sleep_hours, smokes, meal_type(cat), total_calories, avg_protein_g,
    avg_carbohydrates_g, avg_fat_g, avg_fibre_g, total_sugar_g

    Returns 0-100 compatibility score (probability of suitability * 100).
    """
    if model_pipeline is None:
        return round(random.uniform(70, 95), 2)

    total_calories = sum(float(f.get("energy_kcal", 0)) for f in foods)
    avg_protein    = float(np.mean([float(f.get("protein_g", 0)) for f in foods]))
    avg_carbs      = float(np.mean([float(f.get("carbohydrates_g", 0)) for f in foods]))
    avg_fat        = float(np.mean([float(f.get("fat_g", 0)) for f in foods]))
    avg_fiber      = float(np.mean([float(f.get("fibre_g", 0)) for f in foods]))
    total_sugar    = sum(float(f.get("freesugar_g", 0)) for f in foods)

    record = pd.DataFrame([{
        "age":                 user_metrics["age"],
        "gender":              1 if user_metrics["gender"] == "male" else 0,
        "bmi":                 user_metrics["bmi"],
        "activity_index":      user_metrics["activity_index"],
        "blood_pressure":      user_metrics["blood_pressure"],
        "blood_sugar_level":   user_metrics["blood_sugar_level"],
        "sleep_hours":         user_metrics["sleep_hours"],
        "smokes":              user_metrics["smokes"],
        "meal_type":           meal_type,
        "total_calories":      total_calories,
        "avg_protein_g":       avg_protein,
        "avg_carbohydrates_g": avg_carbs,
        "avg_fat_g":           avg_fat,
        "avg_fibre_g":         avg_fiber,
        "total_sugar_g":       total_sugar,
    }])

    try:
        # predict_proba -> [[prob_class_0, prob_class_1]]
        # class 1 = suitable -> convert to 0-100 score
        proba = model_pipeline.predict_proba(record)[0]
        return round(float(proba[1]) * 100, 2)
    except Exception as e:
        logger.warning(f"Model scoring failed ({e}), using random fallback.")
        return round(random.uniform(70, 95), 2)


def _build_health_recommendations(user_profile: dict) -> List[str]:
    """Mirrors api.py recommendations block exactly"""
    recs = []
    if user_profile.get("blood_sugar_level", 0) > 100:
        recs.append("Consider reducing intake of high-sugar foods and simple carbohydrates.")
    if user_profile.get("blood_pressure", 0) > 140:
        recs.append("Focus on reducing sodium intake and saturated fats.")
    if user_profile.get("bmi", 0) >= 25:
        recs.append(f"Your BMI is in the {user_profile.get('bmi_category', '')} range. Consider managing calorie intake.")
    if user_profile.get("smokes") == 1:
        recs.append("Smoking affects health. Consider consulting a healthcare professional.")
    return recs


def _generate_diet_plan(req: PredictRequest, user_metrics: dict):
    """
    Mirrors api.py predict_diet() meal loop exactly.
    Selects one food per category per meal, scores the combo with the ML model.
    """
    if food_df is None:
        raise HTTPException(status_code=503, detail="Food data not loaded. Check FOOD_DATA_PATH.")

    category_map: Dict[str, pd.DataFrame] = {
        cat: food_df[food_df["food_category"] == cat]
        for cat in ["staple", "lentil", "curry", "dessert", "side", "other"]
    }

    diet_plan: Dict[str, MealPlan] = {}
    daily_total_calories = 0.0

    for meal_name, categories in MEAL_STRUCTURE.items():
        selected_rows: List[Any] = []

        for cat in categories:
            cat_df = category_map.get(cat, pd.DataFrame())
            if not cat_df.empty:
                selected_rows.append(cat_df.sample(n=1).iloc[0])
            elif not food_df.empty:
                # Fallback to any food — mirrors api.py behaviour
                selected_rows.append(food_df.sample(n=1).iloc[0])

        # Fill to target count if short
        while len(selected_rows) < len(categories) and not food_df.empty:
            selected_rows.append(food_df.sample(n=1).iloc[0])

        # Score the entire meal combo with the trained model
        combo_score = _score_meal_with_model(user_metrics, selected_rows, meal_name)

        meal_calories = 0.0
        meal_foods: List[FoodItem] = []
        for row in selected_rows:
            kcal = float(row.get("energy_kcal", 0))
            meal_calories += kcal
            meal_foods.append(FoodItem(
                food_name=str(row["food_name"]),
                energy_kcal=round(kcal, 2),
                compatibility_score=combo_score,
            ))

        daily_total_calories += meal_calories
        diet_plan[meal_name] = MealPlan(
            foods=meal_foods,
            total_calories=round(meal_calories, 2),
            avg_compatibility=combo_score,
        )

    return diet_plan, round(daily_total_calories, 2)


# ─────────────────────────────────────────────────────────────────
# Routes
# ─────────────────────────────────────────────────────────────────

@app.get("/health")
def health_check() -> dict:
    """Health probe — called by Spring Boot and monitoring tools"""
    return {
        "status":           "healthy",
        "model_loaded":     model_pipeline is not None,
        "food_data_loaded": food_df is not None,
        "food_data_rows":   int(len(food_df)) if food_df is not None else 0,
    }


@app.post("/predict", response_model=PredictResponse)
def predict(req: PredictRequest) -> PredictResponse:
    """
    Main endpoint called by Spring Boot AiDietService.java.

    Replaces Flask /predict_diet with proper ML scoring.
    Spring Boot sends the user's health profile; this service
    selects meals, scores them with the RandomForestClassifier,
    and returns the full diet plan + nutrition metrics.
    """
    # 1. Compute nutrition metrics
    bmi     = _calculate_bmi(req.height_cm, req.weight_kg)
    bmi_cat = _get_bmi_category(bmi)
    bmr     = round(_compute_bmr(req.weight_kg, req.height_cm, req.age, req.gender), 2)
    tdee    = round(bmr * ACTIVITY_MULTIPLIERS[req.activity_level], 2)
    target  = round(tdee + GOAL_CALORIE_ADJUSTMENT[req.goal], 2)

    protein_g = round(req.weight_kg * 1.6, 1)
    fat_g     = round(target * 0.25 / 9, 1)
    carbs_g   = round(max((target - protein_g * 4 - fat_g * 9) / 4, 0), 1)

    # 2. Build user_metrics dict for model input
    #    activity_index = the multiplier float — matches generate.py training data
    user_metrics = {
        "age":               req.age,
        "gender":            req.gender,
        "bmi":               bmi,
        "activity_index":    ACTIVITY_MULTIPLIERS[req.activity_level],
        "blood_pressure":    req.blood_pressure,
        "blood_sugar_level": req.blood_sugar_level,
        "sleep_hours":       req.sleep_hours,
        "smokes":            req.smokes,
    }

    user_profile = {
        "age":               req.age,
        "gender":            req.gender,
        "weight_kg":         req.weight_kg,
        "height_cm":         req.height_cm,
        "bmi":               bmi,
        "bmi_category":      bmi_cat,
        "blood_sugar_level": req.blood_sugar_level,
        "blood_pressure":    req.blood_pressure,
        "sleep_hours":       req.sleep_hours,
        "smokes":            req.smokes,
        "activity_level":    req.activity_level,
        "goal":              req.goal,
    }

    # 3. Generate diet plan (ML-scored meal combos)
    diet_plan, daily_total = _generate_diet_plan(req, user_metrics)

    # 4. Health recommendations
    recommendations = _build_health_recommendations(user_profile)

    return PredictResponse(
        user_profile=user_profile,
        bmi=bmi,
        bmi_category=bmi_cat,
        bmr=bmr,
        tdee=tdee,
        target_calories=target,
        protein_g=protein_g,
        carbs_g=carbs_g,
        fat_g=fat_g,
        diet_plan=diet_plan,
        daily_summary={
            "total_calories": daily_total,
            "meals_count":    len(diet_plan),
        },
        health_recommendations=recommendations,
    )
