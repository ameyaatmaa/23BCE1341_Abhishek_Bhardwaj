#!/usr/bin/env bash
# Deploy script for Smart Nutrition stack
# Usage: ./deploy.sh [--build] [--pull]

set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT_DIR"

BUILD=false
PULL=false

for arg in "$@"; do
  case "$arg" in
    --build) BUILD=true ;; 
    --pull) PULL=true ;;
    -h|--help)
      echo "Usage: $0 [--build] [--pull]"
      echo "  --build  Build images locally before starting (uses docker compose build or docker build)."
      echo "  --pull   Pull images from registry before starting (uses docker compose pull)."
      exit 0 ;;
    *) echo "Unknown arg: $arg"; exit 2 ;;
  esac
done

check_cmd() {
  command -v "$1" >/dev/null 2>&1 || { echo "ERROR: required command '$1' not found"; exit 3; }
}

wait_for_http() {
  url="$1"
  timeout=${2:-60}
  echo -n "Waiting for $url to become available (timeout ${timeout}s)"
  for i in $(seq 1 $timeout); do
    if curl -sS --max-time 3 "$url" >/dev/null 2>&1; then
      echo " -> OK"
      return 0
    fi
    echo -n .
    sleep 1
  done
  echo "\nTimed out waiting for $url"
  return 1
}

echo "Deploy script starting from $ROOT_DIR"

# Prefer 'docker compose' (newer), fall back to 'docker-compose'
if command -v docker >/dev/null 2>&1; then
  DOCKER_CMD="docker"
else
  echo "ERROR: docker not installed on this host. Install Docker and re-run."
  exit 4
fi

if $DOCKER_CMD compose version >/dev/null 2>&1; then
  COMPOSE_CMD="$DOCKER_CMD compose"
elif command -v docker-compose >/dev/null 2>&1; then
  COMPOSE_CMD="docker-compose"
else
  COMPOSE_CMD=""
fi

if [ -n "$COMPOSE_CMD" ]; then
  echo "Using compose: $COMPOSE_CMD"
  if $PULL; then
    echo "Pulling images via compose..."
    $COMPOSE_CMD pull || echo "Warning: compose pull failed or some images not found"
  fi
  if $BUILD; then
    echo "Building images via compose... (this may take a while)"
    $COMPOSE_CMD build --no-cache
  fi

  echo "Starting services with compose..."
  $COMPOSE_CMD up -d --remove-orphans

  echo "Waiting for AI health and frontend root..."
  wait_for_http http://localhost/ai/health 60 || echo "AI health check failed or timed out"
  wait_for_http http://localhost/ 60 || echo "Frontend root check failed or timed out"

  echo "Compose-based deployment complete. Use '$COMPOSE_CMD ps' to view containers."
  exit 0
fi

# Fallback: No compose available. We'll try to build and run containers directly.
echo "docker compose not found. Falling back to direct docker commands."

echo "Building AI image..."
if $PULL; then
  echo "Pull requested but no compose available; skipping pull for AI image."
fi
if $BUILD; then
  docker build -t smart-nutrition:local .
fi

echo "Creating network 'app-network' if it doesn't exist..."
if ! docker network ls --format '{{.Name}}' | grep -q '^app-network$'; then
  docker network create app-network || true
fi

echo "Starting MongoDB..."
docker run -d --name smart-nutrition-mongodb --network app-network -p 27017:27017 mongo:6 || true

echo "Starting backend (built from smart-nutrition-backend_new)..."
# Build backend image if BUILD is set
if $BUILD; then
  docker build -t smart-nutrition-springboot:local ./smart-nutrition-backend
fi
docker run -d --name smart-nutrition-backend --network app-network smart-nutrition-springboot:local || true

echo "Starting AI container..."
docker run -d --name smart-nutrition-ai --network app-network -p 8000:8000 smart-nutrition:local || true

echo "Starting Nginx (serving frontend build) on host port 80..."
if [ -d "./smart-nutrition-frontend/build" ]; then
  docker run -d --name smart-nutrition-nginx --network app-network -p 80:80 \
    -v "$ROOT_DIR/nginx.conf:/etc/nginx/conf.d/default.conf:ro" \
    -v "$ROOT_DIR/smart-nutrition-frontend/build:/usr/share/nginx/html:ro" \
    nginx:alpine || true
else
  echo "Warning: frontend build not found at ./smart-nutrition-frontend/build. Nginx will run but may serve nothing."
  docker run -d --name smart-nutrition-nginx --network app-network -p 80:80 \
    -v "$ROOT_DIR/nginx.conf:/etc/nginx/conf.d/default.conf:ro" \
    nginx:alpine || true
fi

echo "Waiting for AI and frontend..."
wait_for_http http://localhost:8000/health 60 || echo "AI health check failed or timed out (container port 8000)"
wait_for_http http://localhost/ 60 || echo "Frontend root check failed or timed out"

echo "Fallback docker-run deployment done. Use 'docker ps' to inspect containers."
