import csv
import json
import random
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score
import joblib

def read_csv(filename):
    """
    Reads a CSV file and returns its content as a pandas DataFrame.
    """
    try:
        df = pd.read_csv(filename)
        return df
    except FileNotFoundError:
        print(f"Error: The file '{filename}' was not found.")
        return None
    except Exception as e:
        print(f"An error occurred while reading the file '{filename}': {e}")
        return None

def calculate_bmi(height_cm, weight_kg):
    """
    Calculates Body Mass Index (BMI) given height in cm and weight in kg.
    BMI is calculated as kg/m^2.
    """
    try:
        height_m = pd.to_numeric(height_cm) / 100
        weight_kg = pd.to_numeric(weight_kg)
        if height_m <= 0:
            return None
        return weight_kg / (height_m ** 2)
    except (ValueError, TypeError):
        return None

def categorize_food(food_name):
    """
    Categorizes food items into different types based on their names.
    """
    food_name_lower = food_name.lower()
    
    # Staples (rice, roti, bread, etc.)
    staple_keywords = ['rice', 'roti', 'chapati', 'bread', 'naan', 'paratha', 'poori', 'dosa', 'idli', 'uttapam', 'thepla']
    
    # Lentils/Dal
    lentil_keywords = ['dal', 'lentil', 'moong', 'masoor', 'chana', 'toor', 'urad', 'rajma', 'chickpea', 'gram']
    
    # Curries/Sabzi
    curry_keywords = ['curry', 'sabzi', 'palak', 'aloo', 'gobi', 'bhindi', 'karela', 'baingan', 'paneer', 'chicken', 'mutton', 'fish', 'prawn', 'avial', 'sambar', 'rasam']
    
    # Desserts
    dessert_keywords = ['kheer', 'halwa', 'laddu', 'barfi', 'rasgulla', 'gulab jamun', 'jalebi', 'kulfi', 'ice cream', 'cake', 'biscuit', 'cookie', 'sweet', 'mithai', 'payasam']
    
    # Check for staples
    if any(keyword in food_name_lower for keyword in staple_keywords):
        return 'staple'
    
    # Check for lentils
    if any(keyword in food_name_lower for keyword in lentil_keywords):
        return 'lentil'
    
    # Check for desserts
    if any(keyword in food_name_lower for keyword in dessert_keywords):
        return 'dessert'
    
    # Check for curries
    if any(keyword in food_name_lower for keyword in curry_keywords):
        return 'curry'
    
    # Default category for unmatched items
    return 'other'

def preprocess_data(user_df, food_df):
    """
    Prepares the data for a machine learning model using pandas.
    """
    if user_df is None or food_df is None:
        print("DataFrames are missing. Cannot preprocess.")
        return None, None

    # Process User Data
    user_df['bmi'] = user_df.apply(
        lambda row: calculate_bmi(row['height_cm'], row['weight_kg']), axis=1
    )
    user_df.drop(columns=['height_cm', 'weight_kg'], inplace=True)
    
    # Add food categories to food data
    food_df['food_category'] = food_df['food_name'].apply(categorize_food)
    
    # Fill missing values with a placeholder
    user_df.fillna(0, inplace=True)
    food_df.fillna('Unknown', inplace=True)
    
    return user_df, food_df

def create_meal_combinations(user_df, food_df, num_combinations_per_user=50):
    """
    Creates training data with proper meal combinations for lunch and dinner.
    Lunch: 1 staple + 1 lentil + 1 dessert + 1 curry
    Dinner: 1 staple + 1 curry + 1 dessert
    """
    training_data_list = []
    
    # Drop the columns that are not available from the user in the frontend
    user_df = user_df.drop(columns=['nutrition_quality', 'heart_rate'], errors='ignore')
    
    # Separate foods by category
    staples = food_df[food_df['food_category'] == 'staple']
    lentils = food_df[food_df['food_category'] == 'lentil']
    curries = food_df[food_df['food_category'] == 'curry']
    desserts = food_df[food_df['food_category'] == 'dessert']
    sides = food_df[food_df['food_category'] == 'side']
    
    print(f"Food categories found:")
    print(f"Staples: {len(staples)}")
    print(f"Lentils: {len(lentils)}")
    print(f"Curries: {len(curries)}")
    print(f"Desserts: {len(desserts)}")
    
    for _, user in user_df.iterrows():
        user_metrics = user.to_dict()
        
        # Generate lunch combinations (staple + lentil + dessert + curry)
        for _ in range(num_combinations_per_user // 2):
            if len(staples) > 0 and len(lentils) > 0 and len(desserts) > 0 and len(curries) > 0 and len(sides) > 0:
                # Sample one from each category for lunch
                lunch_staple = staples.sample(n=1).iloc[0]
                lunch_lentil = lentils.sample(n=1).iloc[0]
                lunch_dessert = desserts.sample(n=1).iloc[0]
                lunch_curry = curries.sample(n=1).iloc[0]
                lunch_side = sides.sample(n=1).iloc[0]
                
                # Calculate suitability based on user health metrics
                lunch_foods = [lunch_staple, lunch_lentil, lunch_dessert, lunch_curry, lunch_side]
                lunch_suitability = calculate_meal_suitability(user_metrics, lunch_foods)
                
                # Create training record for lunch
                lunch_record = create_meal_record(user_metrics, lunch_foods, lunch_suitability, 'lunch')
                training_data_list.append(lunch_record)
        
        # Generate dinner combinations (staple + curry + dessert)
        for _ in range(num_combinations_per_user // 2):
            if len(staples) > 0 and len(curries) > 0 and len(desserts) > 0 and len(sides) > 0:
                # Sample one from each category for dinner
                dinner_staple = staples.sample(n=1).iloc[0]
                dinner_curry = curries.sample(n=1).iloc[0]
                dinner_dessert = desserts.sample(n=1).iloc[0]
                dinner_side = sides.sample(n=1).iloc[0]
                
                # Calculate suitability based on user health metrics
                dinner_foods = [dinner_staple, dinner_curry, dinner_dessert, dinner_side]
                dinner_suitability = calculate_meal_suitability(user_metrics, dinner_foods)
                
                # Create training record for dinner
                dinner_record = create_meal_record(user_metrics, dinner_foods, dinner_suitability, 'dinner')
                training_data_list.append(dinner_record)
    
    if not training_data_list:
        return pd.DataFrame()
    
    combined_df = pd.concat(training_data_list, ignore_index=True)
    return combined_df

def calculate_meal_suitability(user_metrics, foods):
    """
    Calculate if a meal combination is suitable for a user based on health metrics.
    """
    total_calories = sum([food['energy_kcal'] for food in foods])
    total_sugar = sum([food.get('freesugar_g', 0) for food in foods])
    total_fat = sum([food.get('fat_g', 0) for food in foods])
    
    # Define suitability rules
    unsuitable_conditions = [
        (user_metrics['bmi'] > 25) and (total_calories > 800),  # High BMI with high calorie meal
        (user_metrics['blood_sugar_level'] > 100) and (total_sugar > 30),  # High blood sugar with high sugar meal
        (user_metrics['blood_pressure'] > 140) and (total_fat > 40),  # High BP with high fat meal
        (user_metrics['age'] > 60) and (total_calories > 700),  # Elderly with high calorie meal
        (user_metrics['smokes'] == 1) and (total_fat > 35),  # Smokers with high fat
    ]
    
    # If any unsuitable condition is met, mark as unsuitable (0), otherwise suitable (1)
    return 0 if any(unsuitable_conditions) else 1

def create_meal_record(user_metrics, foods, suitability, meal_type):
    """
    Create a training record for a meal combination.
    """
    # Calculate aggregated nutritional values
    total_calories = sum([food['energy_kcal'] for food in foods])
    avg_protein = np.mean([food.get('protein_g', 0) for food in foods])
    avg_carbs = np.mean([food.get('carbohydrates_g', 0) for food in foods])
    avg_fat = np.mean([food.get('fat_g', 0) for food in foods])
    avg_fiber = np.mean([food.get('fibre_g', 0) for food in foods])
    total_sugar = sum([food.get('freesugar_g', 0) for food in foods])
    
    # Create record
    record = {
        'age': user_metrics['age'],
        'gender': user_metrics['gender_M'],
        'bmi': user_metrics['bmi'],
        'activity_index': user_metrics['activity_index'],
        'blood_pressure': user_metrics['blood_pressure'],
        'blood_sugar_level': user_metrics['blood_sugar_level'],
        'sleep_hours': user_metrics['sleep_hours'],
        'smokes': user_metrics['smokes'],
        'meal_type': meal_type,
        'total_calories': total_calories,
        'avg_protein_g': avg_protein,
        'avg_carbohydrates_g': avg_carbs,
        'avg_fat_g': avg_fat,
        'avg_fibre_g': avg_fiber,
        'total_sugar_g': total_sugar,
        'food_names': ' | '.join([food['food_name'] for food in foods]),
        'suitability': suitability
    }
    
    return pd.DataFrame([record])

def train_and_save_model(combined_df):
    """
    Trains a RandomForestClassifier model and saves it to a file.
    """
    if combined_df is None or combined_df.empty:
        print("No data available for training.")
        return None

    print(f"Training data shape: {combined_df.shape}")
    print(f"Suitability distribution:\n{combined_df['suitability'].value_counts()}")

    # Define features and target
    X = combined_df.drop(columns=['suitability', 'food_names'])
    y = combined_df['suitability']

    # Define categorical and numerical features for the preprocessor
    numerical_features = X.select_dtypes(include=np.number).columns
    categorical_features = X.select_dtypes(include=['object']).columns

    print(f"Numerical features: {list(numerical_features)}")
    print(f"Categorical features: {list(categorical_features)}")

    # Create the preprocessor pipeline
    preprocessor = ColumnTransformer(
        transformers=[
            ('num', StandardScaler(), numerical_features),
            ('cat', OneHotEncoder(handle_unknown='ignore'), categorical_features)
        ],
        remainder='passthrough'
    )

    # Create the full model pipeline
    model_pipeline = Pipeline(steps=[
        ('preprocessor', preprocessor),
        ('classifier', RandomForestClassifier(n_estimators=100, random_state=42))
    ])

    # Split data into training and testing sets
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42, stratify=y)

    # Train the model
    print("Training the model...")
    model_pipeline.fit(X_train, y_train)

    # Evaluate the model
    y_pred = model_pipeline.predict(X_test)
    print(f"Model Accuracy: {accuracy_score(y_test, y_pred) * 100:.2f}%")

    # Save the entire pipeline, which includes the model and the preprocessor
    joblib.dump(model_pipeline, 'diet_model_pipeline.pkl')
    print("Model and preprocessor saved to 'diet_model_pipeline.pkl'")

    return model_pipeline

def main_train():
    """
    Main function to train and save the model with proper meal combinations.
    """
    user_filename = 'cleaned_user_data.csv'
    food_filename = 'cleaned_food_data.csv'

    print("Reading and preparing data...")
    user_df = read_csv(user_filename)
    food_df = read_csv(food_filename)
    
    if user_df is not None and food_df is not None:
        processed_user_df, processed_food_df = preprocess_data(user_df.copy(), food_df.copy())
        
        if processed_user_df is not None and processed_food_df is not None:
            combined_df = create_meal_combinations(processed_user_df, processed_food_df, num_combinations_per_user=100)
            
            if combined_df is not None and not combined_df.empty:
                train_and_save_model(combined_df)
            else:
                print("Failed to create a combined training dataset.")
    else:
        print("Could not load data files.")

if __name__ == "__main__":
    main_train()