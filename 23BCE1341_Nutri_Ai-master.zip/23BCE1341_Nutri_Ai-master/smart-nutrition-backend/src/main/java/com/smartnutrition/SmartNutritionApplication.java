package com.smartnutrition;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SmartNutritionApplication {

    public static void main(String[] args) {
        SpringApplication.run(SmartNutritionApplication.class, args);
    }
}