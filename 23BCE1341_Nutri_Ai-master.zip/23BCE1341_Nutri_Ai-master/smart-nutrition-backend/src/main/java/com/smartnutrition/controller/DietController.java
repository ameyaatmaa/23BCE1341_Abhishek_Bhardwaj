package com.smartnutrition.controller;

import com.smartnutrition.dto.response.ApiResponse;
import com.smartnutrition.model.DietLog;
import com.smartnutrition.security.jwt.UserPrincipal;
import com.smartnutrition.service.AiDietService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/diet")
@RequiredArgsConstructor
public class DietController {

    private final AiDietService aiDietService;


    @PostMapping("/generate")
    public ResponseEntity<ApiResponse<Map<String, Object>>> generateDietPlan(
            @AuthenticationPrincipal UserPrincipal principal) {
        Map<String, Object> plan = aiDietService.generateDietPlan(principal.getId());
        return ResponseEntity.ok(ApiResponse.ok("Diet plan generated successfully.", plan));
    }

    @GetMapping("/history")
    public ResponseEntity<ApiResponse<Page<DietLog>>> getDietHistory(
            @AuthenticationPrincipal UserPrincipal principal,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {
        Page<DietLog> history = aiDietService.getDietHistory(principal.getId(), page, size);
        return ResponseEntity.ok(ApiResponse.ok(history));
    }
}
