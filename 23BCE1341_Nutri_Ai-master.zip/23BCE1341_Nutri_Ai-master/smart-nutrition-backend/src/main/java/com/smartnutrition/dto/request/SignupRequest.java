package com.smartnutrition.dto.request;

import jakarta.validation.constraints.*;

public record SignupRequest(
    @NotBlank @Size(min = 2, max = 60) String name,
    @NotBlank @Email String email,
    @NotBlank @Size(min = 6, max = 40) String password
) {}
