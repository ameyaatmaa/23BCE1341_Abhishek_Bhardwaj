package com.smartnutrition.dto.request;

import jakarta.validation.constraints.*;


public record UpdateProfileRequest(
    String name,

    @DecimalMin("20") @DecimalMax("300")
    Double weight,           // kg

    @DecimalMin("50") @DecimalMax("250")
    Double height,           // cm

    @Min(10) @Max(120)
    Integer age,

    @Pattern(regexp = "male|female")
    String gender,

    @Pattern(regexp = "sedentary|light|moderate|active|very_active")
    String activityLevel,

    @Pattern(regexp = "lose|maintain|gain")
    String goal,

    // ── Optional vitals for the AI model ──────────────────────────
    @DecimalMin("40") @DecimalMax("500")
    Double bloodSugarLevel,  // mg/dL  (normal fasting: 70-100)

    @DecimalMin("60") @DecimalMax("250")
    Double bloodPressure,    // mmHg systolic (normal: ~120)

    @DecimalMin("1") @DecimalMax("24")
    Double sleepHours,       // hours/night

    @Min(0) @Max(1)
    Integer smokes           // 0 = no, 1 = yes
) {}
