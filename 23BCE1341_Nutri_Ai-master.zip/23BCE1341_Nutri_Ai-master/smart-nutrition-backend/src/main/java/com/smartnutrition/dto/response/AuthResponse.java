package com.smartnutrition.dto.response;

import com.smartnutrition.model.User;

// ── Auth response with tokens ────────────────────────────────────
public record AuthResponse(
    String accessToken,
    String refreshToken,
    String tokenType,
    UserResponse user
) {
    public static AuthResponse of(String accessToken, String refreshToken, User user) {
        return new AuthResponse(accessToken, refreshToken, "Bearer", UserResponse.from(user));
    }
}
