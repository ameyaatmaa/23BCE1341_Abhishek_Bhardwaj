package com.smartnutrition.dto.response;

import com.smartnutrition.model.User;

public record UserResponse(
    String id,
    String name,
    String email,
    String imageUrl,
    String provider,
    // Health profile
    Double weight,
    Double height,
    Integer age,
    String gender,
    String activityLevel,
    String goal,
    // Vitals
    Double bloodSugarLevel,
    Double bloodPressure,
    Double sleepHours,
    Integer smokes
) {
    public static UserResponse from(User user) {
        return new UserResponse(
            user.getId(),
            user.getName(),
            user.getEmail(),
            user.getImageUrl(),
            user.getProvider().name(),
            user.getWeight(),
            user.getHeight(),
            user.getAge(),
            user.getGender(),
            user.getActivityLevel(),
            user.getGoal(),
            user.getBloodSugarLevel(),
            user.getBloodPressure(),
            user.getSleepHours(),
            user.getSmokes()
        );
    }
}
