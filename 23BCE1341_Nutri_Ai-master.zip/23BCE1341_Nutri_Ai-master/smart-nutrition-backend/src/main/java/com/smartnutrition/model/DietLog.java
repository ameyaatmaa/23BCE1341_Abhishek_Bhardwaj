package com.smartnutrition.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.Instant;
import java.util.Map;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Document(collection = "diet_logs")
public class DietLog {

    @Id
    private String id;

    @Indexed
    private String userId;

    // Input snapshot (what was sent to the AI service)
    private Map<String, Object> inputSnapshot;

    // Full AI response stored as-is
    private Map<String, Object> aiResponse;

    // Quick-access top-level fields
    private Double bmi;
    private Double bmr;
    private Double tdee;
    private Double targetCalories;

    @CreatedDate
    private Instant createdAt;
}
