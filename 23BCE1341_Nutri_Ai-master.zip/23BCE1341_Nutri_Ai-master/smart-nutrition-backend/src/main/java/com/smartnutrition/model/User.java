package com.smartnutrition.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.Instant;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Document(collection = "users")
public class User {

    @Id
    private String id;

    @Indexed(unique = true)
    private String email;

    private String name;

    private String password; // null for OAuth2-only users

    private String imageUrl;

    @Builder.Default
    private AuthProvider provider = AuthProvider.LOCAL;

    private String providerId; // Google/GitHub sub or id

    @Builder.Default
    private boolean emailVerified = false;

    // ── Health Profile ──────────────────────────────────────────
    private Double weight;       // kg
    private Double height;       // cm
    private Integer age;
    private String gender;       // "male" | "female"
    private String activityLevel; // "sedentary" | "light" | "moderate" | "active" | "very_active"
    private String goal;          // "lose" | "maintain" | "gain"

    // ── Optional health vitals (used by AI model) ────────────────
    private Double bloodSugarLevel; // mg/dL
    private Double bloodPressure;   // mmHg (systolic)
    private Double sleepHours;      // hours/night
    private Integer smokes;         // 0 = no, 1 = yes

    // ── Timestamps ──────────────────────────────────────────────
    @CreatedDate
    private Instant createdAt;

    @LastModifiedDate
    private Instant updatedAt;

    public enum AuthProvider {
        LOCAL, GOOGLE, GITHUB
    }
}
