package com.smartnutrition.repository;

import com.smartnutrition.model.DietLog;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface DietLogRepository extends MongoRepository<DietLog, String> {
    Page<DietLog> findByUserIdOrderByCreatedAtDesc(String userId, Pageable pageable);
}
