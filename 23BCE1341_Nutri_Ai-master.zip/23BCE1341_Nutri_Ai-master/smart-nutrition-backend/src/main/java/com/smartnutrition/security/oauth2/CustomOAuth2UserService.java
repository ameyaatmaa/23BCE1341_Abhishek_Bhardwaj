package com.smartnutrition.security.oauth2;

import com.smartnutrition.exception.OAuth2AuthenticationProcessingException;
import com.smartnutrition.model.User;
import com.smartnutrition.repository.UserRepository;
import com.smartnutrition.security.jwt.UserPrincipal;
import lombok.RequiredArgsConstructor;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.security.oauth2.client.userinfo.DefaultOAuth2UserService;
import org.springframework.security.oauth2.client.userinfo.OAuth2UserRequest;
import org.springframework.security.oauth2.core.OAuth2AuthenticationException;
import org.springframework.security.oauth2.core.user.OAuth2User;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.client.RestTemplate;

import java.util.List;
import java.util.Map;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class CustomOAuth2UserService extends DefaultOAuth2UserService {

    private final UserRepository userRepository;

    @Override
    public OAuth2User loadUser(OAuth2UserRequest userRequest) throws OAuth2AuthenticationException {
        OAuth2User oAuth2User = super.loadUser(userRequest);
        String registrationId = userRequest.getClientRegistration().getRegistrationId();

        OAuth2UserInfo userInfo = OAuth2UserInfo.of(registrationId, oAuth2User.getAttributes());

        // GitHub private email: fetch from /user/emails if not in user profile
        String email = userInfo.getEmail();
        if (!StringUtils.hasText(email) && "github".equals(registrationId)) {
            email = fetchGitHubEmail(userRequest);
        }

        if (!StringUtils.hasText(email)) {
            throw new OAuth2AuthenticationProcessingException(
                    "Email not found from OAuth2 provider. Please ensure your " + registrationId + " account has a public email.");
        }

        User user = upsertUser(registrationId, userInfo, email);
        return UserPrincipal.create(user, oAuth2User.getAttributes());
    }

    private String fetchGitHubEmail(OAuth2UserRequest userRequest) {
        String accessToken = userRequest.getAccessToken().getTokenValue();
        RestTemplate restTemplate = new RestTemplate();
        HttpHeaders headers = new HttpHeaders();
        headers.setBearerAuth(accessToken);
        HttpEntity<Void> entity = new HttpEntity<>(headers);
        try {
            ResponseEntity<List<Map<String, Object>>> response = restTemplate.exchange(
                    "https://api.github.com/user/emails",
                    HttpMethod.GET,
                    entity,
                    new ParameterizedTypeReference<>() {});
            List<Map<String, Object>> emails = response.getBody();
            if (emails != null) {
                // Prefer primary + verified email
                return emails.stream()
                        .filter(e -> Boolean.TRUE.equals(e.get("primary")) && Boolean.TRUE.equals(e.get("verified")))
                        .map(e -> (String) e.get("email"))
                        .findFirst()
                        .orElse(emails.stream()
                                .filter(e -> Boolean.TRUE.equals(e.get("verified")))
                                .map(e -> (String) e.get("email"))
                                .findFirst()
                                .orElse(null));
            }
        } catch (Exception e) {
            // Fall through to throw below
        }
        return null;
    }

    private User upsertUser(String registrationId, OAuth2UserInfo userInfo, String email) {
        User.AuthProvider provider = userInfo.toAuthProvider(registrationId);

        Optional<User> existingByEmail = userRepository.findByEmail(email);

        if (existingByEmail.isPresent()) {
            User user = existingByEmail.get();
            // Allow login with any OAuth provider for the same verified email.
            // Both Google and GitHub verify email ownership, so they are equivalent.
            user.setName(userInfo.getName());
            user.setImageUrl(userInfo.getImageUrl());
            user.setProviderId(userInfo.getId());
            user.setProvider(provider);
            user.setEmailVerified(true);
            return userRepository.save(user);
        }

        User newUser = User.builder()
                .email(email)
                .name(userInfo.getName())
                .imageUrl(userInfo.getImageUrl())
                .provider(provider)
                .providerId(userInfo.getId())
                .emailVerified(true)
                .build();
        return userRepository.save(newUser);
    }
}
