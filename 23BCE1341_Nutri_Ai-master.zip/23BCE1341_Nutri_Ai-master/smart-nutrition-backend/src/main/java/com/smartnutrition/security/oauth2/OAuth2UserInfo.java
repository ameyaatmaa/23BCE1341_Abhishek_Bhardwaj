package com.smartnutrition.security.oauth2;

import com.smartnutrition.exception.OAuth2AuthenticationProcessingException;
import com.smartnutrition.model.User;

import java.util.Map;

// Abstraction for Oauth providrs
public abstract class OAuth2UserInfo {

    protected final Map<String, Object> attributes;

    protected OAuth2UserInfo(Map<String, Object> attributes) {
        this.attributes = attributes;
    }

    public Map<String, Object> getAttributes() { return attributes; }

    public abstract String getId();
    public abstract String getName();
    public abstract String getEmail();
    public abstract String getImageUrl();

    // ── Factory ──────────────────────────────────────────────────

    public static OAuth2UserInfo of(String registrationId, Map<String, Object> attributes) {
        return switch (registrationId.toLowerCase()) {
            case "google" -> new GoogleOAuth2UserInfo(attributes);
            case "github" -> new GitHubOAuth2UserInfo(attributes);
            default -> throw new OAuth2AuthenticationProcessingException(
                    "OAuth2 login with " + registrationId + " is not supported.");
        };
    }

    // ── Google ───────────────────────────────────────────────────

    static class GoogleOAuth2UserInfo extends OAuth2UserInfo {
        GoogleOAuth2UserInfo(Map<String, Object> attributes) { super(attributes); }

        @Override public String getId()       { return (String) attributes.get("sub"); }
        @Override public String getName()     { return (String) attributes.get("name"); }
        @Override public String getEmail()    { return (String) attributes.get("email"); }
        @Override public String getImageUrl() { return (String) attributes.get("picture"); }
    }

    // ── GitHub ───────────────────────────────────────────────────

    static class GitHubOAuth2UserInfo extends OAuth2UserInfo {
        GitHubOAuth2UserInfo(Map<String, Object> attributes) { super(attributes); }

        @Override public String getId()       { return String.valueOf(attributes.get("id")); }
        @Override public String getName()     { return (String) attributes.get("name"); }
        @Override public String getEmail()    { return (String) attributes.get("email"); }
        @Override public String getImageUrl() { return (String) attributes.get("avatar_url"); }
    }

    // ── Helper ───────────────────────────────────────────────────

    public User.AuthProvider toAuthProvider(String registrationId) {
        return switch (registrationId.toLowerCase()) {
            case "google" -> User.AuthProvider.GOOGLE;
            case "github" -> User.AuthProvider.GITHUB;
            default -> User.AuthProvider.LOCAL;
        };
    }
}
