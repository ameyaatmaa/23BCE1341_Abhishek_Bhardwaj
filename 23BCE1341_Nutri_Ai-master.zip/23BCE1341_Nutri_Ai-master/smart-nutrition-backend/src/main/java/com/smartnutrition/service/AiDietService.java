package com.smartnutrition.service;

import com.smartnutrition.exception.AiServiceException;
import com.smartnutrition.model.DietLog;
import com.smartnutrition.model.User;
import com.smartnutrition.repository.DietLogRepository;
import com.smartnutrition.repository.UserRepository;
import com.smartnutrition.exception.ResourceNotFoundException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.RestTemplate;

import java.util.HashMap;
import java.util.Map;

@Slf4j
@Service
@RequiredArgsConstructor
public class AiDietService {

    private final UserRepository userRepository;
    private final DietLogRepository dietLogRepository;
    private final RestTemplate restTemplate;

    @Value("${app.ai-service.base-url}")
    private String aiServiceBaseUrl;

  //calls python api , pyhton api  generate karta hai diet plan

    @SuppressWarnings("unchecked")
    public Map<String, Object> generateDietPlan(String userId) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("User", "id", userId));

        validateHealthProfile(user);

        // Build payload for Python service
        Map<String, Object> payload = buildAiPayload(user);

        // Call Python AI microservice
        Map<String, Object> aiResult;
        try {
            ResponseEntity<Map<String, Object>> response = restTemplate.exchange(
                    aiServiceBaseUrl + "/predict",
                    HttpMethod.POST,
                    new HttpEntity<>(payload, jsonHeaders()),
                    new ParameterizedTypeReference<>() {}
            );
            aiResult = response.getBody();
        } catch (ResourceAccessException e) {
            log.error("AI service unreachable: {}", e.getMessage());
            throw new AiServiceException("AI service is currently unavailable. Please try again later.");
        } catch (Exception e) {
            log.error("AI service call failed: {}", e.getMessage());
            throw new AiServiceException("Failed to generate diet plan: " + e.getMessage());
        }

        // mongoDB
        DietLog dietLog = DietLog.builder()
                .userId(userId)
                .inputSnapshot(payload)
                .aiResponse(aiResult)
                .bmi(extractDouble(aiResult, "bmi"))
                .bmr(extractDouble(aiResult, "bmr"))
                .tdee(extractDouble(aiResult, "tdee"))
                .targetCalories(extractDouble(aiResult, "target_calories"))
                .build();
        dietLogRepository.save(dietLog);

        return aiResult;
    }

    // paginated diet plan retun hota hai
    public Page<DietLog> getDietHistory(String userId, int page, int size) {
        return dietLogRepository.findByUserIdOrderByCreatedAtDesc(
                userId, PageRequest.of(page, size));
    }

    // ── Helpers ───────────────────────────────────────────────────

    private Map<String, Object> buildAiPayload(User user) {
        Map<String, Object> payload = new HashMap<>();
        // Required fields — field names must match PredictRequest in ai_service.py exactly
        payload.put("weight_kg",      user.getWeight());
        payload.put("height_cm",      user.getHeight());
        payload.put("age",            user.getAge());
        payload.put("gender",         user.getGender());
        payload.put("activity_level", user.getActivityLevel());
        payload.put("goal",           user.getGoal());

        // Optional vitals — send if present, ai_service.py uses healthy defaults otherwise
        if (user.getBloodSugarLevel() != null) payload.put("blood_sugar_level", user.getBloodSugarLevel());
        if (user.getBloodPressure()   != null) payload.put("blood_pressure",    user.getBloodPressure());
        if (user.getSleepHours()      != null) payload.put("sleep_hours",       user.getSleepHours());
        if (user.getSmokes()          != null) payload.put("smokes",            user.getSmokes());
        return payload;
    }

    private void validateHealthProfile(User user) {
        if (user.getWeight() == null || user.getHeight() == null || user.getAge() == null
                || user.getGender() == null || user.getActivityLevel() == null || user.getGoal() == null) {
            throw new IllegalStateException(
                    "Please complete your health profile (weight, height, age, gender, activity level, goal) before generating a diet plan.");
        }
    }

    private HttpHeaders jsonHeaders() {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        return headers;
    }

    private Double extractDouble(Map<String, Object> map, String key) {
        if (map == null || !map.containsKey(key)) return null;
        Object val = map.get(key);
        if (val instanceof Number n) return n.doubleValue();
        return null;
    }
}
