package com.smartnutrition.service;

import com.smartnutrition.dto.request.LoginRequest;
import com.smartnutrition.dto.request.SignupRequest;
import com.smartnutrition.dto.response.AuthResponse;
import com.smartnutrition.exception.BadRequestException;
import com.smartnutrition.model.User;
import com.smartnutrition.repository.UserRepository;
import com.smartnutrition.security.jwt.JwtTokenProvider;
import com.smartnutrition.security.jwt.UserPrincipal;
import lombok.RequiredArgsConstructor;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class AuthService {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    private final AuthenticationManager authenticationManager;
    private final JwtTokenProvider tokenProvider;

    public AuthResponse register(SignupRequest req) {
        if (userRepository.existsByEmail(req.email())) {
            throw new BadRequestException("Email address is already in use.");
        }

        User user = User.builder()
                .name(req.name())
                .email(req.email())
                .password(passwordEncoder.encode(req.password()))
                .provider(User.AuthProvider.LOCAL)
                .emailVerified(false)
                .build();

        user = userRepository.save(user);

        String accessToken = tokenProvider.generateTokenFromUserId(user.getId());
        String refreshToken = tokenProvider.generateRefreshToken(user.getId());

        return AuthResponse.of(accessToken, refreshToken, user);
    }

    public AuthResponse login(LoginRequest req) {
        Authentication authentication = authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(
                        req.email(), req.password())
        );

        // Override: AuthManager uses username (email via UserDetailsService.loadUserByEmail)
        // We swap to use the principal to get the real DB ID
        UserPrincipal principal = (UserPrincipal) authentication.getPrincipal();
        User user = userRepository.findById(principal.getId()).orElseThrow();

        String accessToken = tokenProvider.generateTokenFromUserId(user.getId());
        String refreshToken = tokenProvider.generateRefreshToken(user.getId());

        SecurityContextHolder.getContext().setAuthentication(authentication);
        return AuthResponse.of(accessToken, refreshToken, user);
    }

    public AuthResponse refreshToken(String refreshToken) {
        if (!tokenProvider.validateToken(refreshToken)) {
            throw new BadRequestException("Invalid or expired refresh token.");
        }
        String userId = tokenProvider.getUserIdFromToken(refreshToken);
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new BadRequestException("User not found."));

        String newAccessToken = tokenProvider.generateTokenFromUserId(userId);
        String newRefreshToken = tokenProvider.generateRefreshToken(userId);
        return AuthResponse.of(newAccessToken, newRefreshToken, user);
    }
}
