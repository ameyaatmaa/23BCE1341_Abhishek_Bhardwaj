package com.smartnutrition.service;

import com.smartnutrition.dto.request.UpdateProfileRequest;
import com.smartnutrition.dto.response.UserResponse;
import com.smartnutrition.exception.ResourceNotFoundException;
import com.smartnutrition.model.User;
import com.smartnutrition.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class UserService {

    private final UserRepository userRepository;

    public UserResponse getProfile(String userId) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("User", "id", userId));
        return UserResponse.from(user);
    }

    public UserResponse updateProfile(String userId, UpdateProfileRequest req) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("User", "id", userId));

        if (req.name() != null)           user.setName(req.name());
        if (req.weight() != null)         user.setWeight(req.weight());
        if (req.height() != null)         user.setHeight(req.height());
        if (req.age() != null)            user.setAge(req.age());
        if (req.gender() != null)         user.setGender(req.gender());
        if (req.activityLevel() != null)  user.setActivityLevel(req.activityLevel());
        if (req.goal() != null)           user.setGoal(req.goal());
        // Vitals — used by the Python AI model
        if (req.bloodSugarLevel() != null) user.setBloodSugarLevel(req.bloodSugarLevel());
        if (req.bloodPressure() != null)   user.setBloodPressure(req.bloodPressure());
        if (req.sleepHours() != null)      user.setSleepHours(req.sleepHours());
        if (req.smokes() != null)          user.setSmokes(req.smokes());

        return UserResponse.from(userRepository.save(user));
    }
}
