import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider } from './contexts/AuthContext';
import { ToastProvider } from './contexts/ToastContext';
import ProtectedRoute from './components/ProtectedRoute';

import Home          from './pages/Home';
import Login         from './pages/Login';
import Signup        from './pages/Signup';
import OAuth2Redirect from './pages/OAuth2Redirect';
import Dashboard     from './pages/Dashboard';
import ProfileSetup  from './pages/ProfileSetup';
import DietHistory   from './pages/DietHistory';

export default function App() {
  return (
    <BrowserRouter>
      <AuthProvider>
        <ToastProvider>
          <Routes>
            {/* Public */}
            <Route path="/"               element={<Home />} />
            <Route path="/login"          element={<Login />} />
            <Route path="/signup"         element={<Signup />} />
            <Route path="/oauth2/redirect" element={<OAuth2Redirect />} />

            {/* Protected */}
            <Route path="/dashboard" element={<ProtectedRoute><Dashboard /></ProtectedRoute>} />
            <Route path="/profile"   element={<ProtectedRoute><ProfileSetup /></ProtectedRoute>} />
            <Route path="/history"   element={<ProtectedRoute><DietHistory /></ProtectedRoute>} />

            {/* Fallback */}
            <Route path="*" element={<Navigate to="/" replace />} />
          </Routes>
        </ToastProvider>
      </AuthProvider>
    </BrowserRouter>
  );
}
