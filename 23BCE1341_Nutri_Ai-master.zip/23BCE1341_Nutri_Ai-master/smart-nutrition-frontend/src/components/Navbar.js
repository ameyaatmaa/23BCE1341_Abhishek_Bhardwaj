import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Leaf, Menu, X } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';

export default function Navbar() {
  const { isAuthenticated, logout } = useAuth();
  const navigate = useNavigate();
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener('scroll', onScroll);
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  return (
    <nav className={`fixed top-0 left-0 right-0 z-40 transition-all duration-300 ${scrolled ? 'glass border-b border-white/8' : 'bg-transparent'}`}>
      <div className="max-w-6xl mx-auto px-6 py-4 flex items-center justify-between">
        <Link to="/" className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-xl bg-volt-300 flex items-center justify-center">
            <Leaf size={16} className="text-night-900" />
          </div>
          <span className="font-display font-bold text-white text-lg">NutriAI</span>
        </Link>

        <div className="hidden md:flex items-center gap-8">
          {['Features', 'About'].map(item => (
            <Link key={item} to={`/${item.toLowerCase()}`}
              className="font-body text-sm text-white/50 hover:text-white transition-colors duration-200">
              {item}
            </Link>
          ))}
        </div>

        <div className="hidden md:flex items-center gap-3">
          {isAuthenticated ? (
            <>
              <Link to="/dashboard" className="btn-ghost text-sm py-2 px-4">Dashboard</Link>
              <button onClick={() => { logout(); navigate('/'); }} className="btn-ghost text-sm py-2 px-4">Sign out</button>
            </>
          ) : (
            <>
              <Link to="/login"  className="btn-ghost text-sm py-2 px-4">Sign in</Link>
              <Link to="/signup" className="btn-primary text-sm py-2 px-4">Get started</Link>
            </>
          )}
        </div>

        <button className="md:hidden text-white/60 hover:text-white" onClick={() => setOpen(!open)}>
          {open ? <X size={22} /> : <Menu size={22} />}
        </button>
      </div>

      {/* Mobile menu */}
      {open && (
        <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }}
          className="md:hidden glass border-t border-white/8 px-6 py-4 space-y-3">
          {['Features', 'About'].map(item => (
            <Link key={item} to={`/${item.toLowerCase()}`} onClick={() => setOpen(false)}
              className="block font-body text-sm text-white/60 hover:text-white py-2">
              {item}
            </Link>
          ))}
          <div className="flex flex-col gap-2 pt-2 border-t border-white/8">
            {isAuthenticated ? (
              <Link to="/dashboard" onClick={() => setOpen(false)} className="btn-primary text-sm text-center py-2.5">Dashboard</Link>
            ) : (
              <>
                <Link to="/login"  onClick={() => setOpen(false)} className="btn-ghost text-sm text-center py-2.5">Sign in</Link>
                <Link to="/signup" onClick={() => setOpen(false)} className="btn-primary text-sm text-center py-2.5">Get started</Link>
              </>
            )}
          </div>
        </motion.div>
      )}
    </nav>
  );
}
