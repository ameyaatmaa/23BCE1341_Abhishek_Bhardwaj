import React from 'react';

const sizes = { sm: 'w-4 h-4 border-2', md: 'w-8 h-8 border-2', lg: 'w-12 h-12 border-3' };

export default function Spinner({ size = 'md' }) {
  return (
    <div className={`${sizes[size]} rounded-full border-white/10 border-t-volt-300 animate-spin`} />
  );
}
