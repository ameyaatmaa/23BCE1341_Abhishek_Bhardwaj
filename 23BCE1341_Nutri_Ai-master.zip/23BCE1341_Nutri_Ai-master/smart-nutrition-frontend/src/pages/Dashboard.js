import React, { useState, useEffect, useCallback } from 'react';
import { Link } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { Zap, AlertTriangle, TrendingUp, Flame, Droplets, Activity, ChevronDown, ChevronUp } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { useToast } from '../contexts/ToastContext';
import { generateDietPlan, getDietHistory } from '../services/dietService';
import {
  calculateBMI, calculateBMR, calculateTDEE, calculateTargetCalories,
  getMealEmoji, getCompatibilityColor
} from '../utils/nutritionCalculations';
import Sidebar from '../components/Sidebar';
import Spinner from '../components/Spinner';

const greeting = () => {
  const h = new Date().getHours();
  return h < 12 ? 'Good morning' : h < 17 ? 'Good afternoon' : 'Good evening';
};

const dateStr = () => new Date().toLocaleDateString('en-IN', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' });

function StatCard({ icon: Icon, label, value, sub, color = 'text-volt-300' }) {
  return (
    <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }}
      className="stat-card">
      <div className={`w-9 h-9 rounded-xl flex items-center justify-center mb-3 ${color.replace('text-', 'bg-').replace('-300', '-300/12').replace('-400', '-400/12')}`}>
        <Icon size={17} className={color} />
      </div>
      <p className="font-body text-xs text-white/35 uppercase tracking-wide mb-0.5">{label}</p>
      <p className={`font-display font-bold text-2xl ${color}`}>{value ?? '—'}</p>
      {sub && <p className="font-body text-xs text-white/35 mt-0.5">{sub}</p>}
    </motion.div>
  );
}

function MealCard({ name, meal, index }) {
  const [expanded, setExpanded] = useState(false);
  const compat = getCompatibilityColor(meal.avg_compatibility);
  return (
    <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.08 }}
      className="card">
      <div className="flex items-start justify-between mb-3">
        <div className="flex items-center gap-2">
          <span className="text-2xl">{getMealEmoji(name)}</span>
          <div>
            <h3 className="font-display font-semibold text-white capitalize text-sm">{name}</h3>
            <p className="font-mono text-xs text-white/35">{Math.round(meal.total_calories)} kcal</p>
          </div>
        </div>
        <div className="text-right">
          <span className={`font-mono text-sm font-bold ${compat.text}`}>{Math.round(meal.avg_compatibility)}%</span>
          <p className="font-body text-xs text-white/25">match</p>
        </div>
      </div>

      {/* Compatibility bar */}
      <div className="h-1 bg-white/8 rounded-full overflow-hidden mb-3">
        <motion.div className={`h-full rounded-full ${compat.bar}`}
          initial={{ width: 0 }} animate={{ width: `${meal.avg_compatibility}%` }}
          transition={{ duration: 0.7, delay: index * 0.1, ease: 'easeOut' }} />
      </div>

      {/* Foods toggle */}
      <button onClick={() => setExpanded(!expanded)}
        className="flex items-center gap-1 text-white/30 hover:text-white/60 text-xs font-body transition-colors">
        {expanded ? <ChevronUp size={13} /> : <ChevronDown size={13} />}
        {meal.foods?.length} items
      </button>

      <AnimatePresence>
        {expanded && (
          <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }} className="overflow-hidden">
            <div className="mt-3 space-y-1.5 pt-3 border-t border-white/5">
              {meal.foods?.map((f, i) => (
                <div key={i} className="flex items-center justify-between">
                  <span className="font-body text-xs text-white/60">{f.food_name}</span>
                  <span className="font-mono text-xs text-white/30">{Math.round(f.energy_kcal)} kcal</span>
                </div>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}

export default function Dashboard() {
  const { user } = useAuth();
  const { toast } = useToast();

  const [plan, setPlan]       = useState(null);
  const [loading, setLoading] = useState(false);
  const [histCount, setHistCount] = useState(0);

  const bmi    = calculateBMI(user?.weight, user?.height);
  const bmr    = calculateBMR(user?.weight, user?.height, user?.age, user?.gender);
  const tdee   = calculateTDEE(bmr, user?.activityLevel);
  const target = calculateTargetCalories(tdee, user?.goal);

  const profileComplete = user?.weight && user?.height && user?.age && user?.gender && user?.activityLevel && user?.goal;

  useEffect(() => {
    document.title = 'Dashboard — NutriAI';
    getDietHistory(0, 1).then(r => setHistCount(r.data?.data?.totalElements || 0)).catch(() => {});
  }, []);

  const handleGenerate = useCallback(async () => {
    setLoading(true);
    try {
      const { data } = await generateDietPlan();
      setPlan(data.data);
      toast('Diet plan generated!', 'success');
    } catch (err) {
      const msg = err.response?.data?.message || 'Could not generate plan. Is your profile complete?';
      toast(msg, 'error');
    } finally {
      setLoading(false);
    }
  }, [toast]);

  return (
    <div className="page-bg min-h-screen flex">
      <Sidebar />
      <main className="flex-1 lg:pt-0 pt-16 px-4 sm:px-6 lg:px-10 py-8 overflow-y-auto">

        {/* Welcome */}
        <div className="mb-8">
          <h1 className="font-display font-black text-3xl text-white">
            {greeting()}, <span className="volt-text">{user?.name?.split(' ')[0] || 'there'}</span> 👋
          </h1>
          <p className="font-body text-sm text-white/35 mt-1">{dateStr()}</p>
        </div>

        {/* Incomplete profile warning */}
        {!profileComplete && (
          <motion.div initial={{ opacity: 0, y: -8 }} animate={{ opacity: 1, y: 0 }}
            className="mb-6 flex items-center gap-3 px-5 py-4 rounded-xl bg-yellow-400/8 border border-yellow-400/20">
            <AlertTriangle size={18} className="text-yellow-400 shrink-0" />
            <p className="font-body text-sm text-white/70">
              Complete your health profile to generate diet plans.{' '}
              <Link to="/profile" className="text-volt-300 hover:underline font-medium">Set it up →</Link>
            </p>
          </motion.div>
        )}

        {/* Stats grid */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-8">
          <StatCard icon={Activity}  label="BMI"            value={bmi?.value}       sub={bmi?.category}               color={bmi?.color || 'text-volt-300'} />
          <StatCard icon={Flame}     label="BMR"            value={bmr ? `${bmr}` : null} sub="kcal at rest"           color="text-coral-300" />
          <StatCard icon={TrendingUp} label="TDEE"          value={tdee ? `${tdee}` : null} sub="daily expenditure"    color="text-aqua-300" />
          <StatCard icon={Droplets}  label="Target Calories" value={target ? `${target}` : null} sub={`Goal: ${user?.goal || '—'}`} color="text-volt-300" />
        </div>

        {/* Generate button */}
        <div className="glass rounded-2xl p-6 mb-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <h2 className="font-display font-bold text-white text-lg">Today's Diet Plan</h2>
              <p className="font-body text-sm text-white/35 mt-0.5">
                AI-scored meal combinations based on your health profile
              </p>
            </div>
            <button onClick={handleGenerate} disabled={loading || !profileComplete}
              className="btn-primary flex items-center gap-2 py-3 px-6 text-sm shrink-0 disabled:opacity-40 disabled:cursor-not-allowed">
              {loading ? <><Spinner size="sm" /> Generating…</> : <><Zap size={16} /> Generate Plan</>}
            </button>
          </div>
        </div>

        {/* Diet plan display */}
        <AnimatePresence>
          {plan && (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
              {/* Meals */}
              <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-3 mb-5">
                {Object.entries(plan.diet_plan || {}).map(([name, meal], i) => (
                  <MealCard key={name} name={name} meal={meal} index={i} />
                ))}
              </div>

              {/* Macros */}
              <div className="glass rounded-2xl p-6 mb-5">
                <h3 className="font-display font-semibold text-white text-sm mb-4">Macronutrient Targets</h3>
                <div className="space-y-3">
                  {[
                    { label: 'Protein',      value: plan.protein_g,  max: 200, color: 'bg-aqua-300' },
                    { label: 'Carbohydrates',value: plan.carbs_g,    max: 400, color: 'bg-volt-300' },
                    { label: 'Fat',          value: plan.fat_g,      max: 120, color: 'bg-coral-300' },
                  ].map(({ label, value, max, color }) => (
                    <div key={label}>
                      <div className="flex justify-between mb-1.5">
                        <span className="font-body text-xs text-white/50">{label}</span>
                        <span className="font-mono text-xs text-white/60">{Math.round(value)}g</span>
                      </div>
                      <div className="h-1.5 bg-white/8 rounded-full overflow-hidden">
                        <motion.div className={`h-full rounded-full ${color}`}
                          initial={{ width: 0 }} animate={{ width: `${Math.min((value / max) * 100, 100)}%` }}
                          transition={{ duration: 0.8, ease: 'easeOut' }} />
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Recommendations */}
              {plan.health_recommendations?.length > 0 && (
                <div className="glass rounded-2xl p-6">
                  <h3 className="font-display font-semibold text-white text-sm mb-3">Health Recommendations</h3>
                  <div className="space-y-2">
                    {plan.health_recommendations.map((rec, i) => (
                      <div key={i} className="flex items-start gap-2.5">
                        <AlertTriangle size={13} className="text-yellow-400 mt-0.5 shrink-0" />
                        <p className="font-body text-sm text-white/55">{rec}</p>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </motion.div>
          )}
        </AnimatePresence>

        {/* Quick stats footer */}
        <div className="mt-8 glass rounded-xl px-6 py-4 flex flex-wrap gap-6">
          {[
            ['Plans generated', histCount],
            ['Activity level', user?.activityLevel?.replace('_', ' ') || '—'],
            ['Current goal',   user?.goal || '—'],
          ].map(([label, val]) => (
            <div key={label}>
              <p className="font-body text-xs text-white/30 uppercase tracking-wide">{label}</p>
              <p className="font-display font-semibold text-white capitalize mt-0.5">{val}</p>
            </div>
          ))}
        </div>
      </main>
    </div>
  );
}
