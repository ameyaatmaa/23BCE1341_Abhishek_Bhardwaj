import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronLeft, ChevronRight, ChevronDown, ChevronUp, Calendar, Zap } from 'lucide-react';
import { getDietHistory } from '../services/dietService';
import { getMealEmoji, getCompatibilityColor } from '../utils/nutritionCalculations';
import Sidebar from '../components/Sidebar';

function SkeletonCard() {
  return (
    <div className="glass rounded-2xl p-6 animate-pulse">
      <div className="h-4 bg-white/8 rounded w-40 mb-3" />
      <div className="flex gap-4 mb-4">
        {[1,2,3].map(i => <div key={i} className="h-3 bg-white/5 rounded w-24" />)}
      </div>
      <div className="h-px bg-white/5" />
    </div>
  );
}

function HistoryItem({ item, index }) {
  const [open, setOpen] = useState(false);
  const ai = item.aiResponse || {};
  const plan = ai.diet_plan || {};

  const date = new Date(item.createdAt).toLocaleDateString('en-IN', {
    weekday: 'long', day: 'numeric', month: 'short', year: 'numeric',
    hour: '2-digit', minute: '2-digit',
  });

  return (
    <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.06 }}
      className="glass rounded-2xl overflow-hidden">

      <div className="p-5">
        {/* Header */}
        <div className="flex items-start justify-between gap-4 mb-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <Calendar size={13} className="text-white/30" />
              <span className="font-body text-xs text-white/35">{date}</span>
            </div>
            <h3 className="font-display font-semibold text-white text-sm">Diet Plan</h3>
          </div>
          <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-volt-300/10 border border-volt-300/20">
            <Zap size={12} className="text-volt-300" />
            <span className="font-mono text-xs text-volt-300">{Math.round(ai.target_calories || 0)} kcal</span>
          </div>
        </div>

        {/* Key metrics */}
        <div className="flex flex-wrap gap-4">
          {[
            { l: 'BMI',    v: item.bmi?.toFixed(1) },
            { l: 'BMR',    v: `${Math.round(item.bmr || 0)} kcal` },
            { l: 'TDEE',   v: `${Math.round(item.tdee || 0)} kcal` },
            { l: 'Target', v: `${Math.round(item.targetCalories || 0)} kcal` },
          ].map(({ l, v }) => (
            <div key={l}>
              <p className="font-body text-xs text-white/25 uppercase tracking-wide">{l}</p>
              <p className="font-mono text-sm text-white/70 font-medium">{v || '—'}</p>
            </div>
          ))}
        </div>

        {/* Expand toggle */}
        {Object.keys(plan).length > 0 && (
          <button onClick={() => setOpen(!open)}
            className="mt-4 flex items-center gap-1.5 text-white/30 hover:text-volt-300 text-xs font-body transition-colors">
            {open ? <ChevronUp size={13} /> : <ChevronDown size={13} />}
            {open ? 'Hide meals' : 'View meal plan'}
          </button>
        )}
      </div>

      {/* Expanded meals */}
      <AnimatePresence>
        {open && (
          <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }} className="overflow-hidden border-t border-white/5">
            <div className="p-5 grid sm:grid-cols-2 lg:grid-cols-4 gap-3">
              {Object.entries(plan).map(([name, meal]) => {
                const compat = getCompatibilityColor(meal.avg_compatibility);
                return (
                  <div key={name} className="bg-white/3 border border-white/6 rounded-xl p-3">
                    <div className="flex items-center gap-2 mb-2">
                      <span>{getMealEmoji(name)}</span>
                      <div>
                        <p className="font-display font-semibold text-white text-xs capitalize">{name}</p>
                        <p className="font-mono text-xs text-white/30">{Math.round(meal.total_calories)} kcal</p>
                      </div>
                    </div>
                    <div className="h-0.5 bg-white/5 rounded mb-2">
                      <div className={`h-full rounded ${compat.bar}`} style={{ width: `${meal.avg_compatibility}%` }} />
                    </div>
                    <div className="space-y-0.5">
                      {meal.foods?.slice(0, 3).map((f, i) => (
                        <p key={i} className="font-body text-xs text-white/35 truncate">{f.food_name}</p>
                      ))}
                      {meal.foods?.length > 3 && <p className="font-body text-xs text-white/20">+{meal.foods.length - 3} more</p>}
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Recommendations */}
            {ai.health_recommendations?.length > 0 && (
              <div className="px-5 pb-5">
                <p className="font-body text-xs text-white/30 uppercase tracking-wide mb-2">Recommendations</p>
                {ai.health_recommendations.map((r, i) => (
                  <p key={i} className="font-body text-xs text-white/45 mb-1">• {r}</p>
                ))}
              </div>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}

export default function DietHistory() {
  const [items, setItems]   = useState([]);
  const [page, setPage]     = useState(0);
  const [total, setTotal]   = useState(0);
  const [pages, setPages]   = useState(0);
  const [loading, setLoading] = useState(true);
  const SIZE = 8;

  useEffect(() => { document.title = 'Diet History — NutriAI'; }, []);

  useEffect(() => {
    setLoading(true);
    getDietHistory(page, SIZE)
      .then(r => {
        const d = r.data.data;
        setItems(d.content || []);
        setTotal(d.totalElements || 0);
        setPages(d.totalPages || 0);
      })
      .catch(() => {})
      .finally(() => setLoading(false));
  }, [page]);

  return (
    <div className="page-bg min-h-screen flex">
      <Sidebar />
      <main className="flex-1 lg:pt-0 pt-16 px-4 sm:px-6 lg:px-10 py-8 overflow-y-auto">

        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="font-display font-black text-3xl text-white">Diet History</h1>
            <p className="font-body text-sm text-white/35 mt-1">{total} plan{total !== 1 ? 's' : ''} generated</p>
          </div>
        </div>

        {loading ? (
          <div className="space-y-3">
            {[1,2,3].map(i => <SkeletonCard key={i} />)}
          </div>
        ) : items.length === 0 ? (
          <div className="glass rounded-2xl p-16 text-center">
            <div className="text-5xl mb-4">🥗</div>
            <h2 className="font-display font-bold text-xl text-white mb-2">No plans yet</h2>
            <p className="font-body text-white/40 mb-6">Generate your first diet plan from the dashboard</p>
            <Link to="/dashboard" className="btn-primary inline-flex items-center gap-2 py-2.5 px-6 text-sm">
              <Zap size={15} /> Go to Dashboard
            </Link>
          </div>
        ) : (
          <>
            <div className="space-y-3 mb-6">
              {items.map((item, i) => <HistoryItem key={item.id} item={item} index={i} />)}
            </div>

            {/* Pagination */}
            {pages > 1 && (
              <div className="flex items-center justify-center gap-4">
                <button onClick={() => setPage(p => p - 1)} disabled={page === 0}
                  className="btn-ghost p-2.5 disabled:opacity-30 disabled:cursor-not-allowed">
                  <ChevronLeft size={18} />
                </button>
                <span className="font-body text-sm text-white/40">
                  Page <span className="text-white font-medium">{page + 1}</span> of {pages}
                </span>
                <button onClick={() => setPage(p => p + 1)} disabled={page >= pages - 1}
                  className="btn-ghost p-2.5 disabled:opacity-30 disabled:cursor-not-allowed">
                  <ChevronRight size={18} />
                </button>
              </div>
            )}
          </>
        )}
      </main>
    </div>
  );
}