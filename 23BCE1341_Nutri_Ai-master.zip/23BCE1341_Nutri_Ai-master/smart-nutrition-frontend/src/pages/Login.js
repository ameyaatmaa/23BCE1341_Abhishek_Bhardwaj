import React, { useState, useEffect } from 'react';
import { Link, useNavigate, useSearchParams } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Eye, EyeOff, Leaf, Github, Chrome } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { useToast } from '../contexts/ToastContext';
import Spinner from '../components/Spinner';

const API_URL = process.env.REACT_APP_API_URL || 'http://localhost:8080';

export default function Login() {
  const { login, isAuthenticated } = useAuth();
  const { toast } = useToast();
  const navigate = useNavigate();
  const [params] = useSearchParams();

  const [form, setForm]     = useState({ email: '', password: '' });
  const [show, setShow]     = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError]   = useState('');

  useEffect(() => {
    document.title = 'Sign in — NutriAI';
    if (isAuthenticated) navigate('/dashboard', { replace: true });
    const err = params.get('error');
    if (err) setError(decodeURIComponent(err));
  }, [isAuthenticated, navigate, params]);

  const handleSubmit = async e => {
    e.preventDefault();
    setError(''); setLoading(true);
    try {
      await login(form);
      toast('Welcome back!', 'success');
      navigate('/dashboard');
    } catch (err) {
      const msg = err.response?.data?.message || 'Invalid email or password.';
      setError(msg);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="page-bg min-h-screen flex items-center justify-center px-4 py-12">
      <div className="fixed inset-0 pointer-events-none">
        <div className="orb w-72 h-72 bg-volt-300/8 top-[-60px] right-[10%]" />
        <div className="orb w-64 h-64 bg-aqua-300/6 bottom-[-40px] left-[5%]" />
      </div>

      <motion.div initial={{ opacity: 0, y: 24 }} animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
        className="relative w-full max-w-md">

        {/* Logo */}
        <div className="flex items-center justify-center gap-2 mb-8">
          <div className="w-9 h-9 rounded-xl bg-volt-300 flex items-center justify-center">
            <Leaf size={18} className="text-night-900" />
          </div>
          <span className="font-display font-bold text-xl text-white">NutriAI</span>
        </div>

        <div className="glass-strong rounded-2xl p-8">
          <h1 className="font-display font-bold text-2xl text-white mb-1">Welcome back</h1>
          <p className="font-body text-sm text-white/40 mb-7">Sign in to your account</p>

          {error && (
            <div className="mb-5 px-4 py-3 rounded-xl bg-coral-400/10 border border-coral-400/25 text-coral-300 text-sm font-body">
              {error}
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block font-body text-xs text-white/50 mb-1.5 uppercase tracking-wide">Email</label>
              <input type="email" required placeholder="you@example.com"
                className="input-field" value={form.email}
                onChange={e => setForm(f => ({ ...f, email: e.target.value }))} />
            </div>
            <div>
              <label className="block font-body text-xs text-white/50 mb-1.5 uppercase tracking-wide">Password</label>
              <div className="relative">
                <input type={show ? 'text' : 'password'} required placeholder="••••••••"
                  className="input-field pr-11" value={form.password}
                  onChange={e => setForm(f => ({ ...f, password: e.target.value }))} />
                <button type="button" onClick={() => setShow(!show)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-white/30 hover:text-white/60 transition-colors">
                  {show ? <EyeOff size={16} /> : <Eye size={16} />}
                </button>
              </div>
            </div>

            <button type="submit" disabled={loading}
              className="btn-primary w-full py-3.5 flex items-center justify-center gap-2 mt-2">
              {loading ? <Spinner size="sm" /> : 'Sign in'}
            </button>
          </form>

          <div className="flex items-center gap-3 my-6">
            <div className="flex-1 h-px bg-white/8" />
            <span className="font-body text-xs text-white/25">or continue with</span>
            <div className="flex-1 h-px bg-white/8" />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <button onClick={() => window.location.href = `${API_URL}/oauth2/authorize/google`}
              className="btn-ghost py-2.5 flex items-center justify-center gap-2 text-sm">
              <Chrome size={16} /> Google
            </button>
            <button onClick={() => window.location.href = `${API_URL}/oauth2/authorize/github`}
              className="btn-ghost py-2.5 flex items-center justify-center gap-2 text-sm">
              <Github size={16} /> GitHub
            </button>
          </div>

          <p className="text-center font-body text-sm text-white/35 mt-7">
            Don't have an account?{' '}
            <Link to="/signup" className="text-volt-300 hover:text-volt-400 transition-colors">Sign up free</Link>
          </p>
        </div>
      </motion.div>
    </div>
  );
}
