import React, { useEffect } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { useToast } from '../contexts/ToastContext';
import Spinner from '../components/Spinner';

export default function OAuth2Redirect() {
  const [params] = useSearchParams();
  const { refreshUser } = useAuth();
  const { toast } = useToast();
  const navigate = useNavigate();

  useEffect(() => {
    const token = params.get('token');
    const refreshToken = params.get('refreshToken');

    if (token) {
      localStorage.setItem('token', token);
      if (refreshToken) localStorage.setItem('refreshToken', refreshToken);
      refreshUser()
        .then(() => { toast('Signed in successfully!', 'success'); navigate('/dashboard'); })
        .catch(() => { toast('Sign-in failed. Please try again.', 'error'); navigate('/login'); });
    } else {
      const err = params.get('error');
      navigate(`/login?error=${err || 'oauth_failed'}`);
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <div className="page-bg min-h-screen flex flex-col items-center justify-center gap-4">
      <Spinner size="lg" />
      <p className="font-body text-white/40 text-sm">Signing you in…</p>
    </div>
  );
}