import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronRight, ChevronLeft, Check } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { useToast } from '../contexts/ToastContext';
import { updateProfile } from '../services/dietService';
import { ACTIVITY_LABELS, GOAL_LABELS } from '../utils/nutritionCalculations';
import Sidebar from '../components/Sidebar';
import Spinner from '../components/Spinner';

const STEPS = ['Body Stats', 'Lifestyle', 'Health Vitals'];

const slide = (dir) => ({
  initial: { opacity: 0, x: dir * 40 },
  animate: { opacity: 1, x: 0, transition: { duration: 0.35, ease: [0.22, 1, 0.36, 1] } },
  exit:    { opacity: 0, x: dir * -40, transition: { duration: 0.25 } },
});

export default function ProfileSetup() {
  const { user, refreshUser } = useAuth();
  const { toast } = useToast();
  const navigate = useNavigate();

  const [step, setStep]   = useState(0);
  const [dir, setDir]     = useState(1);
  const [saving, setSaving] = useState(false);
  const [data, setData]   = useState({
    weight: user?.weight || '', height: user?.height || '',
    age: user?.age || '', gender: user?.gender || '',
    activityLevel: user?.activityLevel || '', goal: user?.goal || '',
    bloodSugarLevel: user?.bloodSugarLevel || 90,
    bloodPressure: user?.bloodPressure || 120,
    sleepHours: user?.sleepHours || 7,
    smokes: user?.smokes ?? 0,
  });
  const [errors, setErrors] = useState({});

  useEffect(() => { document.title = 'My Profile — NutriAI'; }, []);

  const set = (k, v) => setData(d => ({ ...d, [k]: v }));

  const validateStep = () => {
    const e = {};
    if (step === 0) {
      if (!data.weight || data.weight < 20 || data.weight > 300) e.weight = 'Enter valid weight (20-300 kg)';
      if (!data.height || data.height < 50 || data.height > 250) e.height = 'Enter valid height (50-250 cm)';
      if (!data.age    || data.age < 10    || data.age > 120)    e.age    = 'Enter valid age (10-120)';
      if (!data.gender) e.gender = 'Select a gender';
    }
    if (step === 1) {
      if (!data.activityLevel) e.activityLevel = 'Select your activity level';
      if (!data.goal)          e.goal          = 'Select your goal';
    }
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const next = () => { if (!validateStep()) return; setDir(1); setStep(s => s + 1); };
  const back = () => { setDir(-1); setStep(s => s - 1); };

  const handleSave = async () => {
    setSaving(true);
    try {
      const payload = {
        weight: parseFloat(data.weight), height: parseFloat(data.height),
        age: parseInt(data.age), gender: data.gender,
        activityLevel: data.activityLevel, goal: data.goal,
        bloodSugarLevel: parseFloat(data.bloodSugarLevel),
        bloodPressure: parseFloat(data.bloodPressure),
        sleepHours: parseFloat(data.sleepHours),
        smokes: data.smokes,
      };
      await updateProfile(payload);
      await refreshUser();
      toast('Profile saved!', 'success');
      navigate('/dashboard');
    } catch {
      toast('Failed to save profile.', 'error');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="page-bg min-h-screen flex">
      <Sidebar />
      <main className="flex-1 lg:pt-0 pt-16 px-4 sm:px-6 lg:px-10 py-8 overflow-y-auto">
        <div className="max-w-2xl mx-auto">

          {/* Progress */}
          <div className="mb-8">
            <div className="flex items-center justify-between mb-3">
              {STEPS.map((s, i) => (
                <div key={s} className="flex items-center gap-2">
                  <div className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-display font-bold transition-all duration-300 ${
                    i < step  ? 'bg-volt-300 text-night-900' :
                    i === step ? 'bg-volt-300/20 border-2 border-volt-300 text-volt-300' :
                                 'bg-white/8 text-white/30'}`}>
                    {i < step ? <Check size={13} /> : i + 1}
                  </div>
                  <span className={`text-sm font-body hidden sm:block transition-colors ${i === step ? 'text-white' : 'text-white/30'}`}>{s}</span>
                  {i < STEPS.length - 1 && <div className={`flex-1 h-px mx-2 w-12 transition-colors ${i < step ? 'bg-volt-300/40' : 'bg-white/8'}`} />}
                </div>
              ))}
            </div>
            <div className="h-1 bg-white/8 rounded-full overflow-hidden">
              <motion.div className="h-full bg-volt-300 rounded-full"
                animate={{ width: `${((step) / (STEPS.length - 1)) * 100}%` }}
                transition={{ duration: 0.4, ease: 'easeOut' }} />
            </div>
          </div>

          <AnimatePresence mode="wait" custom={dir}>
            {/* STEP 0 — Body Stats */}
            {step === 0 && (
              <motion.div key="step0" {...slide(dir)}>
                <div className="glass-strong rounded-2xl p-7">
                  <h2 className="font-display font-bold text-xl text-white mb-1">Body Stats</h2>
                  <p className="font-body text-sm text-white/40 mb-6">Used to calculate your BMI, BMR and calorie targets</p>

                  <div className="grid sm:grid-cols-2 gap-4">
                    {[
                      { k: 'weight', label: 'Weight', unit: 'kg', placeholder: '70' },
                      { k: 'height', label: 'Height', unit: 'cm', placeholder: '175' },
                      { k: 'age',    label: 'Age',    unit: 'yrs', placeholder: '28' },
                    ].map(({ k, label, unit, placeholder }) => (
                      <div key={k}>
                        <label className="block font-body text-xs text-white/50 mb-1.5 uppercase tracking-wide">{label}</label>
                        <div className="relative">
                          <input type="number" placeholder={placeholder}
                            className={`input-field pr-10 ${errors[k] ? 'border-coral-400/50' : ''}`}
                            value={data[k]} onChange={e => set(k, e.target.value)} />
                          <span className="absolute right-3 top-1/2 -translate-y-1/2 text-white/25 text-xs font-mono">{unit}</span>
                        </div>
                        {errors[k] && <p className="text-coral-300 text-xs mt-1">{errors[k]}</p>}
                      </div>
                    ))}

                    <div>
                      <label className="block font-body text-xs text-white/50 mb-1.5 uppercase tracking-wide">Gender</label>
                      <div className="flex gap-2">
                        {['male', 'female'].map(g => (
                          <button key={g} type="button" onClick={() => set('gender', g)}
                            className={`flex-1 py-3 rounded-xl font-body text-sm capitalize transition-all duration-200 border ${
                              data.gender === g
                                ? 'bg-volt-300/15 border-volt-300/40 text-volt-300'
                                : 'bg-white/4 border-white/10 text-white/50 hover:border-white/20'}`}>
                            {g}
                          </button>
                        ))}
                      </div>
                      {errors.gender && <p className="text-coral-300 text-xs mt-1">{errors.gender}</p>}
                    </div>
                  </div>
                </div>
              </motion.div>
            )}

            {/* STEP 1 — Lifestyle */}
            {step === 1 && (
              <motion.div key="step1" {...slide(dir)}>
                <div className="glass-strong rounded-2xl p-7">
                  <h2 className="font-display font-bold text-xl text-white mb-1">Lifestyle</h2>
                  <p className="font-body text-sm text-white/40 mb-6">Determines your daily energy expenditure and calorie targets</p>

                  <div className="mb-6">
                    <label className="block font-body text-xs text-white/50 mb-3 uppercase tracking-wide">Activity Level</label>
                    <div className="space-y-2">
                      {Object.entries(ACTIVITY_LABELS).map(([k, { label, desc }]) => (
                        <button key={k} type="button" onClick={() => set('activityLevel', k)}
                          className={`w-full px-4 py-3.5 rounded-xl border text-left transition-all duration-200 ${
                            data.activityLevel === k
                              ? 'bg-volt-300/12 border-volt-300/35 '
                              : 'bg-white/3 border-white/8 hover:border-white/15'}`}>
                          <div className="flex items-center justify-between">
                            <span className={`font-body font-medium text-sm ${data.activityLevel === k ? 'text-volt-300' : 'text-white/70'}`}>{label}</span>
                            {data.activityLevel === k && <div className="w-4 h-4 rounded-full bg-volt-300 flex items-center justify-center"><Check size={10} className="text-night-900" /></div>}
                          </div>
                          <span className="font-body text-xs text-white/30">{desc}</span>
                        </button>
                      ))}
                    </div>
                    {errors.activityLevel && <p className="text-coral-300 text-xs mt-1">{errors.activityLevel}</p>}
                  </div>

                  <div>
                    <label className="block font-body text-xs text-white/50 mb-3 uppercase tracking-wide">Your Goal</label>
                    <div className="grid grid-cols-3 gap-2">
                      {Object.entries(GOAL_LABELS).map(([k, { label, desc, icon }]) => (
                        <button key={k} type="button" onClick={() => set('goal', k)}
                          className={`px-3 py-4 rounded-xl border text-center transition-all duration-200 ${
                            data.goal === k
                              ? 'bg-volt-300/12 border-volt-300/35'
                              : 'bg-white/3 border-white/8 hover:border-white/15'}`}>
                          <div className={`text-2xl mb-1`}>{icon}</div>
                          <div className={`font-display font-semibold text-sm ${data.goal === k ? 'text-volt-300' : 'text-white/70'}`}>{label}</div>
                          <div className="font-body text-xs text-white/25 mt-0.5">{desc}</div>
                        </button>
                      ))}
                    </div>
                    {errors.goal && <p className="text-coral-300 text-xs mt-1">{errors.goal}</p>}
                  </div>
                </div>
              </motion.div>
            )}

            {/* STEP 2 — Vitals */}
            {step === 2 && (
              <motion.div key="step2" {...slide(dir)}>
                <div className="glass-strong rounded-2xl p-7">
                  <h2 className="font-display font-bold text-xl text-white mb-1">Health Vitals</h2>
                  <div className="flex items-center gap-2 mb-6">
                    <span className="px-2.5 py-0.5 rounded-full bg-aqua-300/12 border border-aqua-300/25 text-aqua-300 text-xs font-body">Optional</span>
                    <p className="font-body text-sm text-white/40">Helps the AI give better meal recommendations</p>
                  </div>

                  <div className="space-y-5">
                    {[
                      { k: 'bloodSugarLevel', label: 'Blood Sugar', unit: 'mg/dL', min: 40,  max: 500, step: 1 },
                      { k: 'bloodPressure',   label: 'Blood Pressure (systolic)', unit: 'mmHg', min: 60, max: 250, step: 1 },
                      { k: 'sleepHours',      label: 'Sleep per night', unit: 'hrs', min: 1, max: 14, step: 0.5 },
                    ].map(({ k, label, unit, min, max, step: s }) => (
                      <div key={k}>
                        <div className="flex justify-between mb-2">
                          <label className="font-body text-xs text-white/50 uppercase tracking-wide">{label}</label>
                          <span className="font-mono text-xs text-volt-300">{data[k]} <span className="text-white/30">{unit}</span></span>
                        </div>
                        <input type="range" min={min} max={max} step={s}
                          value={data[k]} onChange={e => set(k, parseFloat(e.target.value))}
                          className="w-full" />
                        <div className="flex justify-between mt-1">
                          <span className="font-mono text-xs text-white/20">{min}</span>
                          <span className="font-mono text-xs text-white/20">{max}</span>
                        </div>
                      </div>
                    ))}

                    <div>
                      <label className="block font-body text-xs text-white/50 mb-3 uppercase tracking-wide">Do you smoke?</label>
                      <div className="flex gap-3">
                        {[{ v: 0, l: 'No' }, { v: 1, l: 'Yes' }].map(({ v, l }) => (
                          <button key={v} type="button" onClick={() => set('smokes', v)}
                            className={`flex-1 py-3 rounded-xl border font-body text-sm transition-all duration-200 ${
                              data.smokes === v
                                ? v === 0 ? 'bg-volt-300/12 border-volt-300/35 text-volt-300'
                                          : 'bg-coral-400/12 border-coral-400/35 text-coral-300'
                                : 'bg-white/3 border-white/8 text-white/50 hover:border-white/15'}`}>
                            {l}
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Navigation */}
          <div className="flex items-center justify-between mt-6">
            {step > 0 ? (
              <button onClick={back} className="btn-ghost flex items-center gap-2 py-2.5 px-5 text-sm">
                <ChevronLeft size={16} /> Back
              </button>
            ) : <div />}

            {step < STEPS.length - 1 ? (
              <button onClick={next} className="btn-primary flex items-center gap-2 py-2.5 px-6 text-sm">
                Next <ChevronRight size={16} />
              </button>
            ) : (
              <button onClick={handleSave} disabled={saving}
                className="btn-primary flex items-center gap-2 py-2.5 px-6 text-sm">
                {saving ? <Spinner size="sm" /> : <><Check size={16} /> Save Profile</>}
              </button>
            )}
          </div>
        </div>
      </main>
    </div>
  );
}
