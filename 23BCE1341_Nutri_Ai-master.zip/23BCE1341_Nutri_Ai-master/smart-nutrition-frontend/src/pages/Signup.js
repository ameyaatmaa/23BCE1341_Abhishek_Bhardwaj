import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Eye, EyeOff, Leaf, Github, Chrome } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { useToast } from '../contexts/ToastContext';
import Spinner from '../components/Spinner';

const API_URL = process.env.REACT_APP_API_URL || 'http://localhost:8080';

const getStrength = pwd => {
  if (pwd.length === 0) return { score: 0, label: '', color: '' };
  let s = 0;
  if (pwd.length >= 8) s++;
  if (/[A-Z]/.test(pwd)) s++;
  if (/[0-9]/.test(pwd)) s++;
  if (/[^A-Za-z0-9]/.test(pwd)) s++;
  const map = [
    { label: 'Weak',   color: 'bg-coral-400' },
    { label: 'Fair',   color: 'bg-yellow-400' },
    { label: 'Good',   color: 'bg-aqua-300' },
    { label: 'Strong', color: 'bg-volt-300' },
  ];
  return { score: s, ...map[Math.min(s - 1, 3)] };
};

export default function Signup() {
  const { register, isAuthenticated } = useAuth();
  const { toast } = useToast();
  const navigate = useNavigate();

  const [form, setForm]   = useState({ name: '', email: '', password: '', confirm: '' });
  const [show, setShow]   = useState({ pwd: false, confirm: false });
  const [loading, setLoading] = useState(false);
  const [errors, setErrors]  = useState({});

  useEffect(() => {
    document.title = 'Create account — NutriAI';
    if (isAuthenticated) navigate('/dashboard', { replace: true });
  }, [isAuthenticated, navigate]);

  const validate = () => {
    const e = {};
    if (!form.name.trim())          e.name    = 'Name is required';
    if (!/\S+@\S+\.\S+/.test(form.email)) e.email = 'Valid email required';
    if (form.password.length < 6)   e.password = 'At least 6 characters';
    if (form.password !== form.confirm) e.confirm = 'Passwords do not match';
    return e;
  };

  const handleSubmit = async e => {
    e.preventDefault();
    const errs = validate();
    if (Object.keys(errs).length) { setErrors(errs); return; }
    setErrors({}); setLoading(true);
    try {
      await register({ name: form.name, email: form.email, password: form.password });
      toast('Account created! Let\'s set up your profile.', 'success');
      navigate('/profile');
    } catch (err) {
      const msg = err.response?.data?.message || 'Registration failed.';
      setErrors({ submit: msg });
    } finally {
      setLoading(false);
    }
  };

  const strength = getStrength(form.password);

  return (
    <div className="page-bg min-h-screen flex items-center justify-center px-4 py-12">
      <div className="fixed inset-0 pointer-events-none">
        <div className="orb w-80 h-80 bg-aqua-300/7 top-[-40px] left-[-40px]" />
        <div className="orb w-64 h-64 bg-volt-300/6 bottom-[0] right-[5%]" />
      </div>

      <motion.div initial={{ opacity: 0, y: 24 }} animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
        className="relative w-full max-w-md">

        <div className="flex items-center justify-center gap-2 mb-8">
          <div className="w-9 h-9 rounded-xl bg-volt-300 flex items-center justify-center">
            <Leaf size={18} className="text-night-900" />
          </div>
          <span className="font-display font-bold text-xl text-white">NutriAI</span>
        </div>

        <div className="glass-strong rounded-2xl p-8">
          <h1 className="font-display font-bold text-2xl text-white mb-1">Create your account</h1>
          <p className="font-body text-sm text-white/40 mb-7">Free forever. No credit card required.</p>

          {errors.submit && (
            <div className="mb-5 px-4 py-3 rounded-xl bg-coral-400/10 border border-coral-400/25 text-coral-300 text-sm font-body">
              {errors.submit}
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            {[
              { key: 'name',  label: 'Full name', type: 'text',  placeholder: 'Priya Sharma' },
              { key: 'email', label: 'Email',     type: 'email', placeholder: 'you@example.com' },
            ].map(({ key, label, type, placeholder }) => (
              <div key={key}>
                <label className="block font-body text-xs text-white/50 mb-1.5 uppercase tracking-wide">{label}</label>
                <input type={type} placeholder={placeholder} className={`input-field ${errors[key] ? 'border-coral-400/50' : ''}`}
                  value={form[key]} onChange={e => setForm(f => ({ ...f, [key]: e.target.value }))} />
                {errors[key] && <p className="text-coral-300 text-xs mt-1 font-body">{errors[key]}</p>}
              </div>
            ))}

            <div>
              <label className="block font-body text-xs text-white/50 mb-1.5 uppercase tracking-wide">Password</label>
              <div className="relative">
                <input type={show.pwd ? 'text' : 'password'} placeholder="Min. 6 characters"
                  className={`input-field pr-11 ${errors.password ? 'border-coral-400/50' : ''}`}
                  value={form.password} onChange={e => setForm(f => ({ ...f, password: e.target.value }))} />
                <button type="button" onClick={() => setShow(s => ({ ...s, pwd: !s.pwd }))}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-white/30 hover:text-white/60 transition-colors">
                  {show.pwd ? <EyeOff size={16} /> : <Eye size={16} />}
                </button>
              </div>
              {form.password && (
                <div className="mt-2 flex items-center gap-2">
                  <div className="flex-1 h-1 bg-white/8 rounded-full overflow-hidden">
                    <div className={`h-full rounded-full transition-all duration-300 ${strength.color}`}
                      style={{ width: `${(strength.score / 4) * 100}%` }} />
                  </div>
                  <span className={`text-xs font-body ${strength.color?.replace('bg-', 'text-')}`}>{strength.label}</span>
                </div>
              )}
              {errors.password && <p className="text-coral-300 text-xs mt-1 font-body">{errors.password}</p>}
            </div>

            <div>
              <label className="block font-body text-xs text-white/50 mb-1.5 uppercase tracking-wide">Confirm password</label>
              <div className="relative">
                <input type={show.confirm ? 'text' : 'password'} placeholder="Repeat password"
                  className={`input-field pr-11 ${errors.confirm ? 'border-coral-400/50' : ''}`}
                  value={form.confirm} onChange={e => setForm(f => ({ ...f, confirm: e.target.value }))} />
                <button type="button" onClick={() => setShow(s => ({ ...s, confirm: !s.confirm }))}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-white/30 hover:text-white/60 transition-colors">
                  {show.confirm ? <EyeOff size={16} /> : <Eye size={16} />}
                </button>
              </div>
              {errors.confirm && <p className="text-coral-300 text-xs mt-1 font-body">{errors.confirm}</p>}
            </div>

            <button type="submit" disabled={loading}
              className="btn-primary w-full py-3.5 flex items-center justify-center gap-2 mt-2">
              {loading ? <Spinner size="sm" /> : 'Create account'}
            </button>
          </form>

          <div className="flex items-center gap-3 my-6">
            <div className="flex-1 h-px bg-white/8" />
            <span className="font-body text-xs text-white/25">or continue with</span>
            <div className="flex-1 h-px bg-white/8" />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <button onClick={() => window.location.href = `${API_URL}/oauth2/authorize/google`}
              className="btn-ghost py-2.5 flex items-center justify-center gap-2 text-sm">
              <Chrome size={16} /> Google
            </button>
            <button onClick={() => window.location.href = `${API_URL}/oauth2/authorize/github`}
              className="btn-ghost py-2.5 flex items-center justify-center gap-2 text-sm">
              <Github size={16} /> GitHub
            </button>
          </div>

          <p className="text-center font-body text-sm text-white/35 mt-7">
            Already have an account?{' '}
            <Link to="/login" className="text-volt-300 hover:text-volt-400 transition-colors">Sign in</Link>
          </p>
        </div>
      </motion.div>
    </div>
  );
}
