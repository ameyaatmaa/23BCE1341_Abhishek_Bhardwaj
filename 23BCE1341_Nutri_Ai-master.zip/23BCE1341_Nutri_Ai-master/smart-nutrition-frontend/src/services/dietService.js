import api from '../utils/api';

export const generateDietPlan  = ()             => api.post('/api/diet/generate');
export const getDietHistory    = (page=0,size=8) => api.get(`/api/diet/history?page=${page}&size=${size}`);
export const getMyProfile      = ()             => api.get('/api/users/me');
export const updateProfile     = (data)         => api.patch('/api/users/me', data);
