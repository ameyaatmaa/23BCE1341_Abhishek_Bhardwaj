export const calculateBMI = (weightKg, heightCm) => {
  if (!weightKg || !heightCm || heightCm <= 0) return null;
  const value = weightKg / Math.pow(heightCm / 100, 2);
  let category, color;
  if (value < 18.5)       { category = 'Underweight'; color = 'text-aqua-300'; }
  else if (value < 25)    { category = 'Normal';      color = 'text-volt-300'; }
  else if (value < 30)    { category = 'Overweight';  color = 'text-yellow-400'; }
  else                    { category = 'Obese';        color = 'text-coral-400'; }
  return { value: Math.round(value * 10) / 10, category, color };
};

export const calculateBMR = (weightKg, heightCm, age, gender) => {
  if (!weightKg || !heightCm || !age || !gender) return null;
  if (gender === 'male')
    return Math.round(10 * weightKg + 6.25 * heightCm - 5 * age + 5);
  return Math.round(10 * weightKg + 6.25 * heightCm - 5 * age - 161);
};

export const ACTIVITY_MULTIPLIERS = {
  sedentary: 1.2, light: 1.375, moderate: 1.55, active: 1.725, very_active: 1.9,
};

export const calculateTDEE = (bmr, activityLevel) => {
  if (!bmr || !activityLevel) return null;
  return Math.round(bmr * (ACTIVITY_MULTIPLIERS[activityLevel] || 1.2));
};

export const calculateTargetCalories = (tdee, goal) => {
  if (!tdee) return null;
  return tdee + (goal === 'lose' ? -500 : goal === 'gain' ? 500 : 0);
};

export const ACTIVITY_LABELS = {
  sedentary:   { label: 'Sedentary',         desc: 'Office job, little exercise' },
  light:       { label: 'Lightly Active',    desc: 'Light exercise 1-3 days/week' },
  moderate:    { label: 'Moderately Active', desc: 'Moderate exercise 3-5 days/week' },
  active:      { label: 'Very Active',       desc: 'Hard exercise 6-7 days/week' },
  very_active: { label: 'Extremely Active',  desc: 'Physical job + hard training' },
};

export const GOAL_LABELS = {
  lose:     { label: 'Lose Weight',    desc: '500 kcal daily deficit', icon: '↘' },
  maintain: { label: 'Maintain',       desc: 'Stay at current weight',  icon: '→' },
  gain:     { label: 'Gain Muscle',    desc: '500 kcal daily surplus',  icon: '↗' },
};

export const getMealEmoji = (meal) =>
  ({ breakfast: '🌅', lunch: '🥗', dinner: '🌙', snack: '🍎' }[meal] || '🍽');

export const getCompatibilityColor = (score) => {
  if (score >= 80) return { bar: 'bg-volt-300', text: 'text-volt-300' };
  if (score >= 60) return { bar: 'bg-yellow-400', text: 'text-yellow-400' };
  return { bar: 'bg-coral-400', text: 'text-coral-400' };
};
