/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./src/**/*.{js,jsx,ts,tsx}"],
  theme: {
    extend: {
      fontFamily: {
        display: ["'Syne'", "sans-serif"],
        body:    ["'DM Sans'", "sans-serif"],
        mono:    ["'JetBrains Mono'", "monospace"],
      },
      colors: {
        night: {
          50: "#f0f0f8", 100: "#e0e0f0", 200: "#c0c0e0", 300: "#9090c8",
          400: "#6060a8", 500: "#303080", 600: "#202060", 700: "#141440",
          800: "#0c0c28", 900: "#060618", 950: "#03030c",
        },
        volt:  { 300: "#c8ff47", 400: "#b8f030", 500: "#a0e020", 600: "#80b810" },
        coral: { 300: "#ff7b6b", 400: "#ff5c47", 500: "#f03c28" },
        aqua:  { 300: "#47e8ff", 400: "#20d4f0", 500: "#00b8d8" },
      },
      // Add opacity steps that Tailwind doesn't include by default
      opacity: { 3: "0.03", 4: "0.04", 6: "0.06", 7: "0.07", 8: "0.08", 12: "0.12", 15: "0.15" },
      animation: {
        "pulse-slow": "pulse 3s cubic-bezier(0.4, 0, 0.6, 1) infinite",
        "float": "float 6s ease-in-out infinite",
      },
      keyframes: {
        float: {
          "0%, 100%": { transform: "translateY(0px)" },
          "50%":      { transform: "translateY(-12px)" },
        },
      },
      boxShadow: {
        "volt":        "0 0 30px rgba(200,255,71,0.4)",
        "volt-sm":     "0 0 12px rgba(200,255,71,0.3)",
        "glass":       "0 8px 32px rgba(0,0,0,0.4), inset 0 1px 0 rgba(255,255,255,0.08)",
        "glass-hover": "0 16px 48px rgba(0,0,0,0.5), inset 0 1px 0 rgba(255,255,255,0.12)",
      },
    },
  },
  plugins: [],
};